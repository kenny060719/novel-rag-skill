#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文档切分模块
功能：读取书籍文件，按章节/段落切分，标注元数据
"""

import re
import json
import os
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime


class BookSplitter:
    """书籍自动切分器"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        # 优化后的章节识别正则（支持中文数字和阿拉伯数字）
        self.chapter_pattern = config.get('splitting', {}).get(
            'chapter_pattern', 
            r'第.\d?章'
        )
        self.max_paragraph_length = config.get('splitting', {}).get(
            'max_paragraph_length', 
            500
        )
        
    def load_book(self, file_path: str) -> str:
        """
        读取书籍文件
        支持：txt, pdf, epub, docx
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"书籍文件不存在：{file_path}")
        
        suffix = file_path.suffix.lower()
        
        if suffix == '.txt':
            return self._load_txt(file_path)
        elif suffix == '.pdf':
            return self._load_pdf(file_path)
        elif suffix == '.epub':
            return self._load_epub(file_path)
        elif suffix == '.docx':
            return self._load_docx(file_path)
        else:
            raise ValueError(f"不支持的文件格式：{suffix}")
    
    def _load_txt(self, file_path: Path) -> str:
        """读取 TXT 文件"""
        encoding = self.config.get('book', {}).get('encoding', 'utf-8')
        with open(file_path, 'r', encoding=encoding) as f:
            return f.read()
    
    def _load_pdf(self, file_path: Path) -> str:
        """读取 PDF 文件"""
        try:
            import pdfplumber
            text_parts = []
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    text = page.extract_text()
                    if text:
                        text_parts.append(text)
            return '\n\n'.join(text_parts)
        except ImportError:
            raise ImportError("请安装 pdfplumber: pip install pdfplumber")
    
    def _load_epub(self, file_path: Path) -> str:
        """读取 EPUB 文件"""
        try:
            from ebooklib import epub
            book = epub.read_epub(file_path)
            text_parts = []
            for item in book.get_items_of_kind('content'):
                text_parts.append(item.get_content().decode('utf-8'))
            return '\n\n'.join(text_parts)
        except ImportError:
            raise ImportError("请安装 ebooklib: pip install ebooklib")
    
    def _load_docx(self, file_path: Path) -> str:
        """读取 DOCX 文件"""
        try:
            import docx
            doc = docx.Document(file_path)
            text_parts = [para.text for para in doc.paragraphs if para.text.strip()]
            return '\n\n'.join(text_parts)
        except ImportError:
            raise ImportError("请安装 python-docx: pip install python-docx")
    
    def split_by_chapter(self, text: str) -> List[Dict[str, Any]]:
        """
        按章节切分
        返回：章节列表
        """
        # 使用正则匹配章节标题
        pattern = re.compile(f'({self.chapter_pattern})', re.MULTILINE)
        
        # 分割文本
        parts = pattern.split(text)
        
        chapters = []
        # parts 结构：[前言，标题 1, 内容 1, 标题 2, 内容 2, ...]
        for i in range(1, len(parts), 2):
            chapter_title = parts[i]
            chapter_content = parts[i + 1] if i + 1 < len(parts) else ""
            
            if chapter_content.strip():
                chapters.append({
                    'title': chapter_title.strip(),
                    'content': chapter_content.strip()
                })
        
        return chapters
    
    def split_by_paragraph(self, content: str) -> List[str]:
        """
        按段落切分
        保持语义完整，每段不超过 max_paragraph_length 字
        """
        # 先按空行分割
        paragraphs = re.split(r'\n\s*\n', content)
        
        chunks = []
        current_chunk = ""
        
        for para in paragraphs:
            para = para.strip()
            if not para:
                continue
            
            # 如果当前段落太长，进一步切分
            if len(para) > self.max_paragraph_length:
                # 按句子切分
                sentences = re.split(r'([。！？.!?])', para)
                
                temp_para = ""
                for sent in sentences:
                    if len(temp_para) + len(sent) <= self.max_paragraph_length:
                        temp_para += sent
                    else:
                        if temp_para:
                            chunks.append(temp_para.strip())
                        temp_para = sent
                
                if temp_para:
                    chunks.append(temp_para.strip())
            else:
                # 检查累积长度
                if len(current_chunk) + len(para) > self.max_paragraph_length:
                    if current_chunk:
                        chunks.append(current_chunk.strip())
                    current_chunk = para
                else:
                    current_chunk += "\n\n" + para if current_chunk else para
        
        if current_chunk:
            chunks.append(current_chunk.strip())
        
        return chunks
    
    def extract_metadata(self, content: str, chapter_num: int) -> Dict[str, Any]:
        """
        提取章节元数据
        """
        metadata = {
            'chapter': chapter_num,
            'characters': self._extract_characters(content),
            'location': self._extract_locations(content),
            'time': self._extract_time(content),
            'events': self._extract_events(content),
            'word_count': len(content)
        }
        return metadata
    
    def _extract_characters(self, content: str) -> List[str]:
        """提取人物名称（简化版，实际应使用 NER）"""
        # 这里使用简单的中文人名模式
        # 实际项目应使用 spaCy 或 HanLP 等 NER 工具
        pattern = r'[张王李赵刘陈杨黄周吴徐孙朱马胡郭何高林罗郑梁谢宋唐韩冯邓曹彭曾萧田董袁潘于蒋蔡余杜叶程苏魏吕丁任沈姚卢姜崔钟谭陆汪范金石廖贾韦夏邱傅方邹熊孟秦白尹黎万段雷郝孔毛邱范江阎兰岳罗钱严覃武戴莫孔向汤]'
        # 这是一个简化的实现，实际应该更复杂
        return []  # 待完善
    
    def _extract_locations(self, content: str) -> List[str]:
        """提取地点名称"""
        # 简化实现
        return []
    
    def _extract_time(self, content: str) -> str:
        """提取时间信息"""
        # 简化实现
        return ""
    
    def _extract_events(self, content: str) -> List[str]:
        """提取关键事件"""
        # 简化实现
        return []
    
    def split(self, file_path: str) -> List[Dict[str, Any]]:
        """
        完整切分流程
        返回：chunks 列表
        """
        print(f"📖 开始读取书籍：{file_path}")
        text = self.load_book(file_path)
        print(f"✅ 书籍读取完成，总字数：{len(text):,}")
        
        print(f"📑 开始章节切分...")
        chapters = self.split_by_chapter(text)
        print(f"✅ 章节切分完成，共 {len(chapters)} 章")
        
        print(f"✂️  开始段落切分...")
        chunks = []
        for chapter_num, chapter in enumerate(chapters, 1):
            paragraphs = self.split_by_paragraph(chapter['content'])
            
            for para_num, para_content in enumerate(paragraphs, 1):
                chunk = {
                    'id': f"chunk_{chapter_num:03d}_{para_num:03d}",
                    'chapter': chapter_num,
                    'chapter_title': chapter['title'],
                    'paragraph': para_num,
                    'content': para_content,
                    'metadata': self.extract_metadata(para_content, chapter_num)
                }
                chunks.append(chunk)
        
        print(f"✅ 段落切分完成，共 {len(chunks)} 个片段")
        
        return chunks
    
    def save_chunks(self, chunks: List[Dict[str, Any]], output_path: str):
        """保存切分结果"""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(chunks, f, ensure_ascii=False, indent=2)
        
        print(f"💾 已保存到：{output_path}")


def main():
    """主函数"""
    import yaml
    
    # 加载配置
    config_path = Path(__file__).parent / 'config.yaml'
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    
    # 创建切分器
    splitter = BookSplitter(config)
    
    # 切分书籍
    book_path = "data/original/三体第一部.txt"
    chunks = splitter.split(book_path)
    
    # 保存结果
    splitter.save_chunks(chunks, "data/chunks/chunks.json")
    
    # 输出统计
    print("\n📊 切分统计:")
    print(f"  总章节数：{max(c['chapter'] for c in chunks)}")
    print(f"  总片段数：{len(chunks)}")
    print(f"  平均每章片段数：{len(chunks) / max(c['chapter'] for c in chunks):.1f}")


if __name__ == "__main__":
    main()
