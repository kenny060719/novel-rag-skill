#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
风格分析模块
功能：分析原著的词汇、句式、修辞、情感、叙事特征，生成风格提示词
"""

import re
import json
from pathlib import Path
from typing import List, Dict, Any
from collections import Counter


class StyleAnalyzer:
    """文风分析器"""
    
    def __init__(self):
        self.style_features = {}
    
    def analyze(self, chunks: List[Dict[str, Any]], sample_ratio: float = 0.2) -> Dict[str, Any]:
        """分析文风"""
        print("🎨 开始风格分析...")
        
        # 采样
        sample_size = max(int(len(chunks) * sample_ratio), 50)
        import random
        sampled_chunks = random.sample(chunks, min(sample_size, len(chunks)))
        texts = [chunk['content'] for chunk in sampled_chunks]
        full_text = '\n'.join(texts)
        
        print(f"  采样片段：{len(sampled_chunks)} 个")
        print(f"  采样字数：{len(full_text):,} 字")
        
        # 1. 词汇特征
        print("  分析词汇特征...")
        self.style_features['vocabulary'] = self._analyze_vocabulary(texts)
        
        # 2. 句式特征
        print("  分析句式特征...")
        self.style_features['sentence'] = self._analyze_sentence(texts)
        
        # 3. 修辞特征
        print("  分析修辞特征...")
        self.style_features['rhetoric'] = self._analyze_rhetoric(texts)
        
        # 4. 情感特征
        print("  分析情感特征...")
        self.style_features['emotion'] = self._analyze_emotion(texts)
        
        # 5. 叙事特征
        print("  分析叙事特征...")
        self.style_features['narrative'] = self._analyze_narrative(texts)
        
        print("✅ 风格分析完成")
        
        return self.style_features
    
    def _analyze_vocabulary(self, texts: List[str]) -> Dict[str, Any]:
        """词汇特征分析"""
        full_text = '\n'.join(texts)
        
        # 分词（简化：按字统计）
        chars = [c for c in full_text if c.isalpha() or c.isdigit()]
        
        # 词频统计
        char_freq = Counter(chars)
        total_chars = len(chars)
        
        # 常用词
        common_chars = char_freq.most_common(20)
        
        # 词汇丰富度（不同字符数/总字符数）
        vocab_richness = len(char_freq) / total_chars if total_chars > 0 else 0
        
        # 平均词长（简化：假设每词 2 字）
        avg_word_length = 2.0
        
        return {
            'total_chars': total_chars,
            'unique_chars': len(char_freq),
            'vocab_richness': round(vocab_richness, 3),
            'avg_word_length': avg_word_length,
            'common_chars': [{'char': c, 'count': n} for c, n in common_chars]
        }
    
    def _analyze_sentence(self, texts: List[str]) -> Dict[str, Any]:
        """句式特征分析"""
        full_text = '\n'.join(texts)
        
        # 句子分割
        sentences = re.split(r'[。！？.!?]', full_text)
        sentences = [s.strip() for s in sentences if s.strip()]
        
        # 句长统计
        sentence_lengths = [len(s) for s in sentences]
        avg_length = sum(sentence_lengths) / len(sentence_lengths) if sentence_lengths else 0
        
        # 句型分析
        question_count = sum(1 for s in sentences if s.endswith('?') or '？' in s)
        exclaim_count = sum(1 for s in sentences if s.endswith('!') or '！' in s)
        statement_count = len(sentences) - question_count - exclaim_count
        
        # 句式复杂度（长句比例）
        complex_ratio = sum(1 for l in sentence_lengths if l > 40) / len(sentence_lengths) if sentence_lengths else 0
        
        return {
            'total_sentences': len(sentences),
            'avg_length': round(avg_length, 1),
            'min_length': min(sentence_lengths) if sentence_lengths else 0,
            'max_length': max(sentence_lengths) if sentence_lengths else 0,
            'statement_count': statement_count,
            'question_count': question_count,
            'exclaim_count': exclaim_count,
            'complexity_ratio': round(complex_ratio, 3)
        }
    
    def _analyze_rhetoric(self, texts: List[str]) -> Dict[str, Any]:
        """修辞特征分析"""
        full_text = '\n'.join(texts)
        
        # 比喻检测（简化）
        metaphor_patterns = ['像', '如', '仿佛', '似的', '一样']
        metaphor_count = sum(full_text.count(p) for p in metaphor_patterns)
        
        # 排比检测（简化：连续相似结构）
        parallelism_count = full_text.count('，') // 10  # 粗略估计
        
        # 反问检测
        rhetorical_question_count = len(re.findall(r'难道|岂不|何不', full_text))
        
        # 引用检测
        quote_count = full_text.count('"') // 2
        
        total_chars = len(full_text)
        per_10k = 10000 / total_chars if total_chars > 0 else 1
        
        return {
            'metaphor_count': round(metaphor_count * per_10k, 1),
            'parallelism_count': round(parallelism_count * per_10k, 1),
            'rhetorical_question_count': round(rhetorical_question_count * per_10k, 1),
            'quote_count': round(quote_count * per_10k, 1)
        }
    
    def _analyze_emotion(self, texts: List[str]) -> Dict[str, Any]:
        """情感特征分析"""
        full_text = '\n'.join(texts)
        
        # 积极词
        positive_words = ['好', '美', '爱', '希望', '快乐', '幸福', '成功']
        positive_count = sum(full_text.count(w) for w in positive_words)
        
        # 消极词
        negative_words = ['坏', '丑', '恨', '绝望', '痛苦', '悲伤', '失败']
        negative_count = sum(full_text.count(w) for w in negative_words)
        
        # 情感极性
        total = positive_count + negative_count
        polarity = (positive_count - negative_count) / total if total > 0 else 0
        
        # 情感强度（感叹号密度）
        exclaim_density = full_text.count('!') + full_text.count('！')
        intensity = exclaim_density / len(full_text) * 1000 if len(full_text) > 0 else 0
        
        # 语调判断
        if polarity > 0.2:
            tone = '积极'
        elif polarity < -0.2:
            tone = '消极'
        else:
            tone = '中性'
        
        return {
            'tone': tone,
            'polarity': round(polarity, 3),
            'positive_count': positive_count,
            'negative_count': negative_count,
            'intensity': round(intensity, 2)
        }
    
    def _analyze_narrative(self, texts: List[str]) -> Dict[str, Any]:
        """叙事特征分析"""
        full_text = '\n'.join(texts)
        
        # 人称检测
        first_person = full_text.count('我') + full_text.count('我们')
        second_person = full_text.count('你') + full_text.count('你们')
        third_person = full_text.count('他') + full_text.count('她') + full_text.count('它') + full_text.count('他们')
        
        # 判断视角
        max_count = max(first_person, second_person, third_person)
        if max_count == first_person:
            pov = '第一人称'
        elif max_count == second_person:
            pov = '第二人称'
        else:
            pov = '第三人称'
        
        # 对话比例（引号内容）
        dialogue_chars = len(re.findall(r'"[^"]*"', full_text))
        dialogue_ratio = dialogue_chars / len(full_text) * 100 if len(full_text) > 0 else 0
        
        # 叙事节奏（动词密度）
        verb_density = len(re.findall(r'[了着过]', full_text)) / len(full_text) * 100 if len(full_text) > 0 else 0
        
        # 节奏判断
        if verb_density > 5:
            pace = '快速'
        elif verb_density < 3:
            pace = '缓慢'
        else:
            pace = '中速'
        
        return {
            'pov': pov,
            'first_person_count': first_person,
            'second_person_count': second_person,
            'third_person_count': third_person,
            'dialogue_ratio': round(dialogue_ratio, 1),
            'pace': pace,
            'verb_density': round(verb_density, 2)
        }
    
    def generate_prompt(self) -> str:
        """生成风格化提示词"""
        vocab = self.style_features.get('vocabulary', {})
        sentence = self.style_features.get('sentence', {})
        rhetoric = self.style_features.get('rhetoric', {})
        emotion = self.style_features.get('emotion', {})
        narrative = self.style_features.get('narrative', {})
        
        prompt = f"""【写作风格要求】

## 词汇特征
- 平均词长：{vocab.get('avg_word_length', 2.0)} 字
- 词汇丰富度：{vocab.get('vocab_richness', 0.6)}
- 常用字：{', '.join([c['char'] for c in vocab.get('common_chars', [])[:10]])}

## 句式特征
- 平均句长：{sentence.get('avg_length', 30)} 字
- 句式复杂度：{'高' if sentence.get('complexity_ratio', 0) > 0.3 else '中' if sentence.get('complexity_ratio', 0) > 0.15 else '低'}
- 陈述句：{sentence.get('statement_count', 0)} 句
- 疑问句：{sentence.get('question_count', 0)} 句
- 感叹句：{sentence.get('exclaim_count', 0)} 句

## 修辞特征
- 比喻密度：{rhetoric.get('metaphor_count', 10)} 次/万字
- 排比使用：{rhetoric.get('parallelism_count', 5)} 次/万字
- 反问使用：{rhetoric.get('rhetorical_question_count', 3)} 次/万字

## 情感基调
- 整体语调：{emotion.get('tone', '中性')}
- 情感极性：{emotion.get('polarity', 0)}
- 情感强度：{emotion.get('intensity', 5)}

## 叙事风格
- 叙事视角：{narrative.get('pov', '第三人称')}
- 叙事节奏：{narrative.get('pace', '中速')}
- 对话比例：{narrative.get('dialogue_ratio', 25)}%

请严格模仿以上风格进行创作。
"""
        
        return prompt
    
    def export(self, output_path: str):
        """导出风格档案"""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # 保存 JSON
        json_path = output_path.with_suffix('.json')
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(self.style_features, f, ensure_ascii=False, indent=2)
        
        # 保存 Markdown
        md_path = output_path.with_suffix('.md')
        prompt = self.generate_prompt()
        with open(md_path, 'w', encoding='utf-8') as f:
            f.write("# 写作风格档案\n\n")
            f.write(prompt)
        
        print(f"💾 风格档案已保存：{md_path}")


def main():
    """主函数"""
    # 加载切分结果
    chunks_path = Path(__file__).parent / 'data' / 'chunks' / 'chunks.json'
    with open(chunks_path, 'r', encoding='utf-8') as f:
        chunks = json.load(f)
    
    # 创建风格分析器
    analyzer = StyleAnalyzer()
    
    # 分析
    analyzer.analyze(chunks, sample_ratio=0.2)
    
    # 导出
    analyzer.export(Path(__file__).parent / 'data' / 'style_profile')


if __name__ == "__main__":
    main()
