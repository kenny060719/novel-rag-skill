#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
全局已写索引模块
功能：跟踪已写内容，防止跨章重复，支持覆盖率检查
"""

import json
import hashlib
from pathlib import Path
from typing import Dict, List, Set, Any, Tuple
from datetime import datetime
from collections import defaultdict


class WrittenIndex:
    """全局已写索引"""
    
    def __init__(self, index_path: str = "output/written_index.json"):
        self.index_path = Path(index_path)
        self.data = {
            'concepts': {},  # 概念 -> [章节列表]
            'paragraph_hashes': [],  # 段落指纹列表
            'chapter_map': {},  # 章节号 -> 概念列表
            'statistics': {
                'total_chapters': 0,
                'completed_chapters': 0,
                'total_concepts': 0,
                'duplicate_count': 0
            }
        }
        self._load()
    
    def _load(self):
        """加载索引"""
        if self.index_path.exists():
            with open(self.index_path, 'r', encoding='utf-8') as f:
                self.data = json.load(f)
            print(f"💾 已加载全局索引：{len(self.data['concepts'])} 个概念")
    
    def _save(self):
        """保存索引"""
        self.index_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.index_path, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
    
    def add_concept(self, concept: str, chapter_num: int):
        """添加概念到索引"""
        if concept not in self.data['concepts']:
            self.data['concepts'][concept] = []
        
        if chapter_num not in self.data['concepts'][concept]:
            self.data['concepts'][concept].append(chapter_num)
        
        # 更新章节映射
        if chapter_num not in self.data['chapter_map']:
            self.data['chapter_map'][chapter_num] = []
        
        if concept not in self.data['chapter_map'][chapter_num]:
            self.data['chapter_map'][chapter_num].append(concept)
        
        self.data['statistics']['total_concepts'] = len(self.data['concepts'])
    
    def add_paragraph(self, text: str, chapter_num: int) -> str:
        """添加段落指纹"""
        # 计算段落哈希
        paragraph_hash = hashlib.md5(text.encode('utf-8')).hexdigest()
        
        # 检查是否重复
        is_duplicate = paragraph_hash in self.data['paragraph_hashes']
        
        if not is_duplicate:
            self.data['paragraph_hashes'].append(paragraph_hash)
        else:
            self.data['statistics']['duplicate_count'] += 1
        
        return paragraph_hash
    
    def check_duplicate(self, text: str) -> Tuple[bool, float]:
        """
        检查文本是否重复
        返回：(是否重复，相似度)
        """
        # 简化实现：检查完全重复
        paragraph_hash = hashlib.md5(text.encode('utf-8')).hexdigest()
        is_duplicate = paragraph_hash in self.data['paragraph_hashes']
        
        # TODO: 实现语义相似度检查（使用 Embedding）
        
        return is_duplicate, 1.0 if is_duplicate else 0.0
    
    def get_concept_chapters(self, concept: str) -> List[int]:
        """获取概念出现的章节"""
        return self.data['concepts'].get(concept, [])
    
    def get_chapter_concepts(self, chapter_num: int) -> List[str]:
        """获取章节包含的概念"""
        return self.data['chapter_map'].get(chapter_num, [])
    
    def check_coverage(self, chapter_num: int, source_concepts: List[str], 
                      written_concepts: List[str]) -> Dict[str, Any]:
        """
        检查覆盖率
        返回：覆盖率报告
        """
        source_set = set(source_concepts)
        written_set = set(written_concepts)
        
        covered = source_set & written_set
        missing = source_set - written_set
        
        coverage_rate = len(covered) / len(source_set) * 100 if source_set else 100
        
        return {
            'chapter': chapter_num,
            'source_concepts': len(source_set),
            'written_concepts': len(written_set),
            'covered_concepts': len(covered),
            'missing_concepts': list(missing),
            'coverage_rate': round(coverage_rate, 1),
            'passed': coverage_rate >= 80
        }
    
    def finalize_chapter(self, chapter_num: int, concepts: List[str], 
                        paragraphs: List[str]):
        """完成章节，更新索引"""
        # 添加概念
        for concept in concepts:
            self.add_concept(concept, chapter_num)
        
        # 添加段落指纹
        for para in paragraphs:
            self.add_paragraph(para, chapter_num)
        
        # 更新统计
        self.data['statistics']['completed_chapters'] += 1
        
        # 保存
        self._save()
        
        print(f"  ✅ 第{chapter_num}章 已更新到全局索引")
        print(f"     概念数：{len(concepts)}")
        print(f"     段落数：{len(paragraphs)}")
        print(f"     总概念数：{self.data['statistics']['total_concepts']}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        return self.data['statistics']
    
    def generate_report(self) -> str:
        """生成全局报告"""
        stats = self.data['statistics']
        
        report = f"""# 全局索引报告

**生成时间**: {datetime.now().isoformat()}

## 统计信息
- 总章节数：{stats['total_chapters']}
- 已完成章节：{stats['completed_chapters']}
- 总概念数：{stats['total_concepts']}
- 重复段落数：{stats['duplicate_count']}

## 概念分布
"""
        
        # 概念出现频率
        concept_freq = [(k, len(v)) for k, v in self.data['concepts'].items()]
        concept_freq.sort(key=lambda x: x[1], reverse=True)
        
        report += "\n### TOP 20 高频概念\n\n"
        for concept, freq in concept_freq[:20]:
            chapters = self.data['concepts'][concept]
            report += f"- **{concept}**: {freq} 章 ({', '.join(map(str, chapters))})\n"
        
        return report


class ConceptExtractor:
    """概念提取器"""
    
    def __init__(self):
        self.stopwords = set(['的', '了', '是', '在', '他', '有', '这', '个', '我', '就'])
    
    def extract_from_text(self, text: str, top_k: int = 20) -> List[str]:
        """从文本中提取关键概念"""
        try:
            import jieba
            import jieba.analyse
            
            # 使用 TF-IDF 提取关键词
            keywords = jieba.analyse.extract_tags(
                text, 
                topK=top_k, 
                withWeight=False
            )
            
            # 过滤停用词
            concepts = [kw for kw in keywords if kw not in self.stopwords and len(kw) > 1]
            
            return concepts
        except ImportError:
            # 简化实现：按词频
            words = text.split()
            from collections import Counter
            word_freq = Counter(words)
            return [w for w, c in word_freq.most_common(top_k) if len(w) > 1]
    
    def extract_from_chunks(self, chunks: List[Dict]) -> List[str]:
        """从多个片段中提取概念"""
        all_text = '\n'.join([chunk.get('content', '') for chunk in chunks])
        return self.extract_from_text(all_text, top_k=30)


def main():
    """测试"""
    # 创建索引
    index = WrittenIndex('output/test_written_index.json')
    
    # 测试添加概念
    index.add_concept('汪淼', 1)
    index.add_concept('汪淼', 2)
    index.add_concept('史强', 1)
    index.add_concept('宇宙闪烁', 3)
    
    # 测试重复检查
    text1 = "汪淼抬起头，夜空中的星星开始闪烁"
    text2 = "汪淼抬起头，夜空中的星星开始闪烁"  # 重复
    
    is_dup1, score1 = index.check_duplicate(text1)
    index.add_paragraph(text1, 1)
    
    is_dup2, score2 = index.check_duplicate(text2)
    
    print(f"文本 1 重复：{is_dup1}")
    print(f"文本 2 重复：{is_dup2}")
    
    # 测试覆盖率
    source = ['汪淼', '史强', '宇宙闪烁', '倒计时']
    written = ['汪淼', '史强']
    
    coverage = index.check_coverage(1, source, written)
    print(f"\n覆盖率：{coverage['coverage_rate']}%")
    print(f"缺失概念：{coverage['missing_concepts']}")
    
    # 保存
    index._save()
    print(f"\n索引已保存：{index.index_path}")


if __name__ == "__main__":
    main()
