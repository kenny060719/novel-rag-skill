#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
复述写作引擎 - 用自己的话复述
功能：理解内容后重新表达，不抄袭原著
"""

import json
from typing import List, Dict, Any


class ParaphraseEngine:
    """复述引擎（用自己的话）"""
    
    def __init__(self, style_prompt: str = ""):
        self.style_prompt = style_prompt
    
    def paraphrase(self, source_chunks: List[Dict], chapter_info: Dict) -> str:
        """
        用自己的话复述章节内容
        
        原则：
        1. 理解原著核心情节
        2. 用自己的语言重新表达
        3. 不重不漏（覆盖关键点，不重复）
        4. 标注情节来源（不是引用原文）
        """
        
        # 1. 提取关键情节
        key_events = self._extract_key_events(source_chunks)
        
        # 2. 理解人物关系
        character_relations = self._understand_characters(source_chunks)
        
        # 3. 组织复述结构
        structure = self._organize_structure(key_events)
        
        # 4. 用自己的话复述
        content = self._write_paraphrase(structure, character_relations)
        
        return content
    
    def _extract_key_events(self, chunks: List[Dict]) -> List[Dict]:
        """提取关键情节（不是原文）"""
        events = []
        
        for chunk in chunks:
            content = chunk.get('content', '')
            
            # 提取情节要点（用自己的话总结）
            event = {
                'what': '发生了什么',  # 事件
                'who': '谁参与的',     # 人物
                'why': '为什么发生',   # 原因
                'result': '结果如何'    # 结果
            }
            events.append(event)
        
        return events
    
    def _understand_characters(self, chunks: List[Dict]) -> Dict:
        """理解人物关系"""
        return {
            'main_characters': [],
            'relations': {},
            'motivations': {}
        }
    
    def _organize_structure(self, events: List[Dict]) -> List[Dict]:
        """组织复述结构"""
        # 按逻辑顺序组织（不是简单按原文顺序）
        structure = []
        
        for event in events:
            structure.append({
                'type': '情节概述',  # 不是原文摘抄
                'content': '用简洁语言概括情节'
            })
        
        return structure
    
    def _write_paraphrase(self, structure: List[Dict], characters: Dict) -> str:
        """
        用自己的话写复述稿
        
        要求：
        1. 每段 200-300 字
        2. 用简洁语言概括
        3. 不直接引用原文
        4. 标注情节来源章节
        """
        
        paraphrase = []
        
        for section in structure:
            # 用自己的话复述
            text = f"""
【情节概述】
{section['content']}

[情节来源：第 X 章]
"""
            paraphrase.append(text)
        
        return '\n\n'.join(paraphrase)


def create_paraphrase_prompt(chapter_info: Dict, key_points: List[str]) -> str:
    """
    创建复述提示词（强调用自己的话）
    """
    return f"""
你是专业的内容复述师，请用自己的话复述以下内容。

【复述要求】
❌ 禁止：
- 直接抄袭原著原文
- 大段引用原著句子
- 照搬原著描写

✅ 必须：
- 用自己的语言重新表达
- 概括核心情节，不纠缠细节
- 保持情节完整，不重不漏
- 简洁明了，逻辑清晰

【复述结构】
1. 开篇概述（50-100 字）
   - 时间、地点、主要人物
   - 核心冲突/事件

2. 情节发展（200-300 字）
   - 事件起因
   - 发展过程
   - 关键转折

3. 高潮部分（200-300 字）
   - 核心冲突
   - 人物行动
   - 情节推进

4. 结局概述（100-150 字）
   - 事件结果
   - 人物命运
   - 留下悬念

【关键情节点】
{chr(10).join(f"- {point}" for point in key_points)}

【输出格式】
# 第 X 章：[章节标题]

[开篇概述]
用自己的话概括...

[情节发展]
用自己的话复述...

[高潮部分]
用自己的话描述...

[结局概述]
用自己的话总结...

【情节来源】
- 主要情节来自原著第 X 章
- 人物关系参考原著第 X-Y 章

开始复述：
"""


# 示例：正确的复述 vs 错误的复述

EXAMPLE_CORRECT = """
# 第 1 章：空手套白狼

[开篇概述]
2006 年夏，河州市。企业家杜林祥卷入了一场政治漩涡。当地首富万顺龙突然被带走调查，
而杜林祥的生意也受到了牵连。

[情节发展]
杜林祥与合伙人周志斌在酒后商议对策。周志斌提议通过政府关系解决问题，
但杜林祥担心事情闹大。此时，神秘女子马晓静出现，透露这次事件背后涉及
更高层的政治博弈——有人想借万顺龙案扳倒常务副省长姜菊人。

[高潮部分]
杜林祥面临抉择：是继续深耕本地市场，还是寻求外部支持？他与深圳咨询公司
合作制作开发方案，预付了五百万费用。同时，他开始接触各方势力，试图在
复杂的政商关系中找到生存空间。

[结局概述]
第一章结束时，杜林祥已深陷局中。他意识到这不仅是商业竞争，更是一场政治
博弈。而他手中唯一的筹码，就是那块尚未获批的土地。

【情节来源】
- 主要情节来自原著第 1 章
- 人物关系参考原著第 1-3 章
"""

EXAMPLE_WRONG = """
# 第 1 章：空手套白狼

洪西首富万顺龙被深夜抓走。洪西省的省会河州，刚遭遇了一场骤雨遍扫。
大雨从下午三点一直下到晚上七点。闷热了许久，这雨一下，浇熄了蝉鸣，
淋湿了天地。世人莫不盼望天行霹雳，地作汪洋，将那秽物一并涤清...

[引用：第 1 章 第 1 段]
"""

print("✅ 复述引擎已加载")
print("核心原则：用自己的话复述，不抄袭原著")
