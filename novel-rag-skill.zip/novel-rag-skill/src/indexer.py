#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
向量索引模块
功能：文本向量化，构建 HNSW + IVF-PQ 双层索引，实现快速检索
"""

import json
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from datetime import datetime


class TextEmbedder:
    """文本向量化器"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.model_name = config.get('embedding', {}).get(
            'model', 
            'text-embedding-3-small'
        )
        self.dimension = config.get('embedding', {}).get(
            'dimension', 
            1536
        )
        self.batch_size = config.get('embedding', {}).get(
            'batch_size', 
            100
        )
        self.model = None
    
    def load_model(self):
        """加载 Embedding 模型"""
        try:
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(self.model_name)
            print(f"✅ Embedding 模型加载完成：{self.model_name}")
        except ImportError:
            print("⚠️  sentence-transformers 未安装，使用模拟向量")
            self.model = None
        except Exception as e:
            print(f"⚠️  模型加载失败：{e}，使用模拟向量")
            self.model = None
    
    def encode(self, texts: List[str], batch_size: Optional[int] = None) -> np.ndarray:
        """
        向量化文本列表
        """
        if batch_size is None:
            batch_size = self.batch_size
        
        if self.model is None:
            # 返回模拟向量（用于测试）
            return self._mock_encode(texts)
        
        embeddings = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            batch_embeddings = self.model.encode(batch)
            embeddings.append(batch_embeddings)
            print(f"  向量化进度：{min(i + batch_size, len(texts))}/{len(texts)}")
        
        return np.vstack(embeddings)
    
    def _mock_encode(self, texts: List[str]) -> np.ndarray:
        """生成模拟向量（用于测试）"""
        np.random.seed(42)
        return np.random.rand(len(texts), self.dimension).astype(np.float32)


class VectorIndexer:
    """向量索引器"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.embedder = TextEmbedder(config)
        
        # 章节索引配置
        self.chapter_index_type = config.get('index', {}).get(
            'chapter_index_type', 
            'hnsw'
        )
        self.chapter_hnsw_m = config.get('index', {}).get(
            'chapter_hnsw_m', 
            32
        )
        
        # 段落索引配置
        self.paragraph_index_type = config.get('index', {}).get(
            'paragraph_index_type', 
            'ivf_pq'
        )
        self.paragraph_ivf_nlist = config.get('index', {}).get(
            'paragraph_ivf_nlist', 
            1000
        )
        self.paragraph_ivf_m = config.get('index', {}).get(
            'paragraph_ivf_m', 
            8
        )
        self.paragraph_ivf_nbits = config.get('index', {}).get(
            'paragraph_ivf_nbits', 
            8
        )
        
        self.chapter_index = None
        self.paragraph_index = None
        self.metadata_db = None
    
    def build_index(self, chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        构建双层索引
        """
        print("📊 开始构建向量索引...")
        
        # 1. 准备数据
        print("  准备数据...")
        chapter_texts = []
        paragraph_texts = []
        chapter_map = {}  # chapter_num -> index
        
        # 按章节分组
        chapters_dict = {}
        for chunk in chunks:
            chap_num = chunk['chapter']
            if chap_num not in chapters_dict:
                chapters_dict[chap_num] = {
                    'title': chunk['chapter_title'],
                    'content': [],
                    'chunks': []
                }
            chapters_dict[chap_num]['content'].append(chunk['content'])
            chapters_dict[chap_num]['chunks'].append(chunk)
        
        # 生成章节摘要
        for chap_num, chap_data in sorted(chapters_dict.items()):
            chapter_texts.append(f"{chap_data['title']}：{''.join(chap_data['content'][:500])}")
            chapter_map[chap_num] = len(chapter_texts) - 1
        
        # 段落文本
        for chunk in chunks:
            paragraph_texts.append(chunk['content'])
        
        print(f"  章节数：{len(chapter_texts)}")
        print(f"  段落数：{len(paragraph_texts)}")
        
        # 2. 向量化
        print("  向量化章节...")
        self.embedder.load_model()
        chapter_embeddings = self.embedder.encode(chapter_texts)
        
        print("  向量化段落...")
        paragraph_embeddings = self.embedder.encode(paragraph_texts)
        
        # 3. 构建章节索引（HNSW）
        print("  构建章节索引（HNSW）...")
        self.chapter_index = self._build_hnsw_index(chapter_embeddings)
        
        # 4. 构建段落索引（IVF-PQ）
        print("  构建段落索引（IVF-PQ）...")
        self.paragraph_index = self._build_ivf_pq_index(paragraph_embeddings)
        
        # 5. 存储元数据
        self.metadata_db = {
            'chapters': list(chapters_dict.values()),
            'chunks': chunks,
            'chapter_map': chapter_map
        }
        
        print("✅ 索引构建完成")
        
        return {
            'chapter_index': self.chapter_index,
            'paragraph_index': self.paragraph_index,
            'metadata_db': self.metadata_db
        }
    
    def _build_hnsw_index(self, embeddings: np.ndarray):
        """构建 HNSW 索引"""
        try:
            import faiss
            
            dimension = embeddings.shape[1]
            index = faiss.IndexHNSWFlat(dimension, self.chapter_hnsw_m)
            index.add(embeddings)
            
            return index
        except ImportError:
            print("⚠️  faiss 未安装，使用简易索引")
            return {'type': 'mock', 'embeddings': embeddings}
    
    def _build_ivf_pq_index(self, embeddings: np.ndarray):
        """构建 IVF-PQ 索引"""
        try:
            import faiss
            
            dimension = embeddings.shape[1]
            n_points = len(embeddings)
            
            # 小数据集使用 flat 索引
            if n_points < 1000:
                print(f"    数据量较小 ({n_points})，使用 Flat 索引...")
                index = faiss.IndexFlatL2(dimension)
                index.add(embeddings)
                return index
            
            # 量化器
            quantizer = faiss.IndexFlatL2(dimension)
            
            # 动态调整 nlist
            nlist = min(self.paragraph_ivf_nlist, max(4, n_points // 50))
            print(f"    使用 nlist={nlist}")
            
            # IVF-PQ 索引
            index = faiss.IndexIVFPQ(
                quantizer, 
                dimension,
                nlist,
                self.paragraph_ivf_m,
                self.paragraph_ivf_nbits
            )
            
            # 训练
            print("    训练 IVF 索引...")
            index.train(embeddings)
            
            # 添加
            print("    添加向量...")
            index.add(embeddings)
            
            return index
        except ImportError:
            print("⚠️  faiss 未安装，使用简易索引")
            return {'type': 'mock', 'embeddings': embeddings}
        except Exception as e:
            print(f"⚠️  IVF 索引构建失败：{e}，使用 Flat 索引")
            index = faiss.IndexFlatL2(dimension)
            index.add(embeddings)
            return index
    
    def search(self, query: str, top_k: int = 10, filters: Optional[Dict] = None) -> List[Dict[str, Any]]:
        """
        检索相关片段
        """
        print(f"  检索查询：{query[:50]}...")
        
        # 向量化查询
        query_vector = self.embedder.encode([query])[0]
        
        # 章节级检索（快速定位）
        chapter_results = self._search_chapter(query_vector, k=5)
        
        # 段落级检索（精细匹配）
        paragraph_results = self._search_paragraph(query_vector, k=top_k * 2)
        
        # 融合结果
        merged = self._fuse_results(chapter_results, paragraph_results)
        
        # 过滤
        if filters:
            merged = self._apply_filters(merged, filters)
        
        # 重排序
        reranked = self._rerank(query, merged)
        
        # 返回 Top-K
        return reranked[:top_k]
    
    def _search_chapter(self, query_vector: np.ndarray, k: int = 5) -> List[Dict]:
        """章节级检索"""
        if isinstance(self.chapter_index, dict):
            # 模拟检索
            return self.metadata_db['chapters'][:k]
        
        try:
            import faiss
            
            distances, indices = self.chapter_index.search(
                query_vector.reshape(1, -1), 
                k
            )
            
            results = []
            for idx, dist in zip(indices[0], distances[0]):
                if idx < len(self.metadata_db['chapters']):
                    results.append({
                        'type': 'chapter',
                        'chapter': list(self.metadata_db['chapter_map'].keys())[idx],
                        'score': 1 / (1 + dist)
                    })
            
            return results
        except Exception as e:
            print(f"⚠️  章节检索失败：{e}")
            return []
    
    def _search_paragraph(self, query_vector: np.ndarray, k: int = 20) -> List[Dict]:
        """段落级检索"""
        if isinstance(self.paragraph_index, dict):
            # 模拟检索
            chunks = self.metadata_db['chunks']
            return [
                {
                    'type': 'paragraph',
                    'chunk': chunk,
                    'score': np.random.rand()
                }
                for chunk in chunks[:k]
            ]
        
        try:
            import faiss
            
            distances, indices = self.paragraph_index.search(
                query_vector.reshape(1, -1), 
                k
            )
            
            results = []
            for idx, dist in zip(indices[0], distances[0]):
                if idx < len(self.metadata_db['chunks']):
                    results.append({
                        'type': 'paragraph',
                        'chunk': self.metadata_db['chunks'][idx],
                        'score': 1 / (1 + dist)
                    })
            
            return results
        except Exception as e:
            print(f"⚠️  段落检索失败：{e}")
            return []
    
    def _fuse_results(self, chapter_results: List[Dict], paragraph_results: List[Dict]) -> List[Dict]:
        """融合检索结果（RRF 算法）"""
        # 简化实现：直接使用段落结果
        return paragraph_results
    
    def _apply_filters(self, results: List[Dict], filters: Dict) -> List[Dict]:
        """应用过滤器"""
        filtered = []
        
        for result in results:
            chunk = result.get('chunk', {})
            
            # 章节范围过滤
            if 'chapter_range' in filters:
                start, end = filters['chapter_range']
                if chunk.get('chapter', 0) < start or chunk.get('chapter', 0) > end:
                    continue
            
            filtered.append(result)
        
        return filtered
    
    def _rerank(self, query: str, results: List[Dict]) -> List[Dict]:
        """重排序（简化实现）"""
        # 按分数排序
        return sorted(results, key=lambda x: x.get('score', 0), reverse=True)
    
    def save_index(self, output_dir: str):
        """保存索引"""
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        try:
            import faiss
            
            # 保存章节索引
            if self.chapter_index and not isinstance(self.chapter_index, dict):
                faiss.write_index(self.chapter_index, str(output_dir / 'chapter_index.faiss'))
            
            # 保存段落索引
            if self.paragraph_index and not isinstance(self.paragraph_index, dict):
                faiss.write_index(self.paragraph_index, str(output_dir / 'paragraph_index.faiss'))
            
            # 保存元数据
            with open(output_dir / 'metadata.json', 'w', encoding='utf-8') as f:
                json.dump(self.metadata_db, f, ensure_ascii=False, indent=2)
            
            print(f"💾 索引已保存到：{output_dir}")
        except Exception as e:
            print(f"⚠️  保存索引失败：{e}")


def main():
    """主函数"""
    import yaml
    
    # 加载配置
    config_path = Path(__file__).parent / 'config.yaml'
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    
    # 加载切分结果
    chunks_path = Path(__file__).parent / 'data' / 'chunks' / 'chunks.json'
    with open(chunks_path, 'r', encoding='utf-8') as f:
        chunks = json.load(f)
    
    # 创建索引器
    indexer = VectorIndexer(config)
    
    # 构建索引
    indexer.build_index(chunks)
    
    # 保存索引
    indexer.save_index(Path(__file__).parent / 'index')
    
    # 测试检索
    print("\n🔍 测试检索:")
    query = "汪淼看到宇宙闪烁"
    results = indexer.search(query, top_k=5)
    
    print(f"检索结果：{len(results)} 个片段")
    for i, result in enumerate(results, 1):
        chunk = result.get('chunk', {})
        print(f"  {i}. 第{chunk.get('chapter', '?')}章 - 相似度：{result.get('score', 0):.3f}")


if __name__ == "__main__":
    main()
