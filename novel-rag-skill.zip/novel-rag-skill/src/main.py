#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能小说复述 Skill - 主入口
用法：
  python main.py build <书籍文件>     # 构建知识库
  python main.py write [选项]         # 开始创作
  python main.py check <文件>         # 质量检查
  python main.py progress             # 查看进度
"""

import sys
import yaml
from pathlib import Path
from datetime import datetime


def print_banner():
    """打印横幅"""
    print("=" * 60)
    print("📚 智能小说复述 Skill v3.0")
    print("=" * 60)


def cmd_build(book_path: str):
    """构建知识库"""
    print_banner()
    print(f"📖 书籍：{book_path}")
    print(f"⏰ 时间：{datetime.now().isoformat()}")
    print()
    
    # 使用 auto_reproducer
    from auto_reproducer import AutoReproducer
    
    reproducer = AutoReproducer()
    result = reproducer.build_index_only(book_path)
    
    print(f"\n✅ 索引构建完成")
    print(f"📁 输出位置：{result.get('index_dir', 'N/A')}")


def cmd_write(mode: str = 'full', **kwargs):
    """开始创作"""
    print_banner()
    print(f"✍️  模式：{mode}")
    print(f"⏰ 时间：{datetime.now().isoformat()}")
    print()
    
    # 使用 auto_reproducer
    from auto_reproducer import AutoReproducer
    
    reproducer = AutoReproducer()
    
    if mode == 'full':
        result = reproducer.create_paraphrase_only()
        print(f"\n✅ 创作完成")
        print(f"📁 输出位置：{result.get('output_dir', 'N/A')}")
    
    elif mode == 'chapter':
        chapter = kwargs.get('chapter', 1)
        result = reproducer.create_single_chapter(chapter)
        print(f"\n✅ 第{chapter}章创作完成")
        print(f"📁 输出位置：{result.get('output_file', 'N/A')}")


def cmd_check(filepath: str):
    """质量检查"""
    print_banner()
    print(f"📄 文件：{filepath}")
    print()
    
    from strict_quality_checker_v2 import StrictQualityCheckerV2
    
    # 读取文件
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 简化检查
    word_count = len(content)
    paragraphs = len([p for p in content.split('\n\n') if p.strip()])
    
    print(f"字数：{word_count} 字")
    print(f"段落：{paragraphs} 段")
    print(f"✅ 文件存在")


def cmd_progress():
    """查看进度"""
    print_banner()
    print("📊 进度查看功能开发中...")


def cmd_help():
    """显示帮助"""
    print("""
📚 智能小说复述 Skill - 使用帮助

命令:
  build <书籍文件>              构建知识库（切分 + 索引 + 知识库 + 风格）
  write [选项]                  开始创作
    --mode full                 全书创作（默认）
    --mode chapter --chapter N  创作第 N 章
    --mode range --start N --end M  创作第 N-M 章
    --mode custom --request "..."  自定义请求
  check <文件>                  质量检查
  progress                      查看进度
  help                          显示帮助

示例:
  python main.py build data/original/沧浪之水.txt
  python main.py write --mode full
  python main.py write --mode chapter --chapter 3
  python main.py check output/chapter_001.md
  python main.py progress
""")


def main():
    """主函数"""
    if len(sys.argv) < 2:
        cmd_help()
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == 'build':
        if len(sys.argv) < 3:
            print("❌ 请指定书籍文件路径")
            print("用法：python main.py build <书籍文件>")
            sys.exit(1)
        cmd_build(sys.argv[2])
    
    elif command == 'write':
        # 解析参数
        mode = 'full'
        kwargs = {}
        
        i = 2
        while i < len(sys.argv):
            if sys.argv[i] == '--mode':
                mode = sys.argv[i + 1] if i + 1 < len(sys.argv) else 'full'
                i += 2
            elif sys.argv[i] == '--chapter':
                kwargs['chapter'] = int(sys.argv[i + 1]) if i + 1 < len(sys.argv) else 1
                i += 2
            elif sys.argv[i] == '--start':
                kwargs['start'] = int(sys.argv[i + 1]) if i + 1 < len(sys.argv) else 1
                i += 2
            elif sys.argv[i] == '--end':
                kwargs['end'] = int(sys.argv[i + 1]) if i + 1 < len(sys.argv) else 5
                i += 2
            elif sys.argv[i] == '--request':
                kwargs['request'] = sys.argv[i + 1] if i + 1 < len(sys.argv) else ''
                i += 2
            else:
                i += 1
        
        cmd_write(mode, **kwargs)
    
    elif command == 'check':
        if len(sys.argv) < 3:
            print("❌ 请指定文件路径")
            print("用法：python main.py check <文件>")
            sys.exit(1)
        cmd_check(sys.argv[2])
    
    elif command == 'progress':
        cmd_progress()
    
    elif command == 'help' or command == '--help':
        cmd_help()
    
    else:
        print(f"❌ 未知命令：{command}")
        cmd_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
