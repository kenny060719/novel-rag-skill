#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
严格质检模块 v2.0 - 修复版
功能：更合理的评分标准 + 更严格的抄袭检测
"""

from typing import List, Dict, Any, Tuple
import re


class StrictQualityCheckerV2:
    """严格质检器 v2.0（修复版）"""
    
    def __init__(self, source_chunks: List[Dict], target_length: int = 1800):
        self.source_chunks = source_chunks
        self.source_text = '\n'.join([c.get('content', '') for c in source_chunks])
        self.target_length = target_length  # 目标字数
    
    def check_paraphrase(self, paraphrase: str) -> Dict[str, Any]:
        """
        严格质检（v2.0 标准）
        """
        results = {
            'plagiarism': self._check_plagiarism_v2(paraphrase),
            'accuracy': self._check_accuracy(paraphrase),
            'completeness': self._check_completeness_v2(paraphrase),
            'readability': self._check_readability(paraphrase),
            'word_count': self._check_word_count_v2(paraphrase),
            'total_score': 0,
            'passed': False,
            'errors': [],
            'suggestions': []
        }
        
        # 一票否决：严重抄袭
        if results['plagiarism']['continuous_same'] >= 20:
            results['total_score'] = 0
            results['passed'] = False
            results['errors'].append(f"严重抄袭：连续{results['plagiarism']['continuous_same']}字相同")
            return results
        
        # 计算加权总分
        weights = {
            'plagiarism': 0.30,
            'accuracy': 0.25,
            'completeness': 0.20,
            'readability': 0.15,
            'word_count': 0.10
        }
        
        total = sum(
            results[k]['score'] * w 
            for k, w in weights.items()
        )
        
        results['total_score'] = round(total, 1)
        results['passed'] = total >= 80
        
        # 收集错误和建议
        if not results['plagiarism']['passed']:
            results['errors'].append(f"抄袭检测：{results['plagiarism']['message']}")
            results['suggestions'].append("请用自己的话重新表达，避免连续 10 字相同")
        
        if not results['accuracy']['passed']:
            results['errors'].append(f"情节准确性：{results['accuracy']['message']}")
            results['suggestions'].append("检查人物关系、时间线、事件顺序")
        
        if not results['completeness']['passed']:
            results['errors'].append(f"完整性：{results['completeness']['message']}")
            results['suggestions'].append(f"补充遗漏的关键情节")
        
        if not results['word_count']['passed']:
            results['errors'].append(f"字数：{results['word_count']['message']}")
            results['suggestions'].append(f"目标字数：{self.target_length}字（±200 字）")
        
        return results
    
    def _check_plagiarism_v2(self, paraphrase: str) -> Dict[str, Any]:
        """
        抄袭检测 v2.0（更严格）
        
        规则：
        - 连续 10-15 字相同：扣 20 分
        - 连续 15-20 字相同：扣 50 分
        - 连续≥20 字相同：直接 0 分（一票否决）
        """
        clean_paraphrase = re.sub(r'\[引用.*?\]', '', paraphrase)
        clean_paraphrase = re.sub(r'[,.!?.,:;:"\s]', '', clean_paraphrase)
        clean_source = re.sub(r'[,.!?.,:;:"\s]', '', self.source_text)
        
        max_continuous = 0
        plagiarism_count = 0
        
        for i in range(len(clean_paraphrase) - 10):
            for length in range(10, 30):
                if i + length > len(clean_paraphrase):
                    break
                segment = clean_paraphrase[i:i + length]
                if segment in clean_source:
                    max_continuous = max(max_continuous, length)
                    plagiarism_count += 1
                else:
                    break
        
        # 评分
        if max_continuous < 10 and plagiarism_count < 5:
            score = 100
            message = "无抄袭"
            passed = True
        elif max_continuous < 15 and plagiarism_count < 10:
            score = 80
            message = f"轻微相似（连续{max_continuous}字，{plagiarism_count}处）"
            passed = True
        elif max_continuous < 20 and plagiarism_count < 20:
            score = 50
            message = f"中度相似（连续{max_continuous}字，{plagiarism_count}处）"
            passed = False
        else:
            score = 0
            message = f"严重抄袭（连续{max_continuous}字相同）"
            passed = False
        
        return {
            'score': score,
            'passed': passed,
            'message': message,
            'continuous_same': max_continuous,
            'plagiarism_count': plagiarism_count
        }
    
    def _check_accuracy(self, paraphrase: str) -> Dict[str, Any]:
        """
        情节准确性检查
        
        检查项：
        - 人物关系正确（10 分）
        - 时间线正确（10 分）
        - 事件顺序正确（5 分）
        """
        score = 100
        errors = []
        
        # 检查人物关系（简化：检查人名是否一致）
        source_names = self._extract_names(self.source_text)
        paraphrase_names = self._extract_names(paraphrase)
        
        missing_names = source_names - paraphrase_names
        if missing_names:
            score -= 10
            errors.append(f"遗漏人物：{', '.join(missing_names)}")
        
        # 检查时间线（简化：检查时间词顺序）
        source_times = self._extract_times(self.source_text)
        paraphrase_times = self._extract_times(paraphrase)
        
        if source_times and paraphrase_times:
            if source_times != paraphrase_times:
                score -= 10
                errors.append("时间线可能有误")
        
        # 检查事件顺序（简化：检查关键词顺序）
        key_events = ['毕业', '报到', '办公室', '会议', '反思']
        positions = {event: paraphrase.find(event) for event in key_events if event in paraphrase}
        
        if len(positions) >= 3:
            # 检查顺序是否合理
            sorted_events = sorted(positions.items(), key=lambda x: x[1])
            event_order = [e[0] for e in sorted_events]
            
            if '毕业' in event_order and '报到' in event_order:
                if event_order.index('毕业') > event_order.index('报到'):
                    score -= 5
                    errors.append("事件顺序错误：毕业应该在报到之前")
        
        message = f"情节准确性良好（{score}分）" if score >= 80 else f"情节有误（{score}分）"
        
        return {
            'score': max(0, score),
            'passed': score >= 80,
            'message': message,
            'errors': errors
        }
    
    def _extract_names(self, text: str) -> set:
        """提取人名"""
        names = set()
        # 常见人名模式
        patterns = [r'池大为', r'丁小槐', r'马厅长', r'许小曼', r'董柳']
        for pattern in patterns:
            if pattern in text:
                names.add(pattern)
        return names
    
    def _extract_times(self, text: str) -> list:
        """提取时间词"""
        times = []
        patterns = [r'1985 年', r'第一天', r'会议.*后', r'夜深人静']
        for pattern in patterns:
            if re.search(pattern, text):
                times.append(pattern)
        return times
    
    def _check_completeness_v2(self, paraphrase: str) -> Dict[str, Any]:
        """
        完整性检查 v2.0（更详细）
        """
        # 提取关键情节点
        key_events = [
            '池大为研究生毕业',
            '分配到省卫生厅',
            '与丁小槐共事',
            '两人性格对比',
            '第一次会议',
            '理想与现实的冲突',
            '内心反思'
        ]
        
        covered = []
        missing = []
        
        for event in key_events:
            # 检查是否覆盖（允许同义表达）
            keywords = event.split()
            if any(kw in paraphrase for kw in keywords):
                covered.append(event)
            else:
                missing.append(event)
        
        coverage_rate = len(covered) / len(key_events) * 100
        
        # 评分
        if coverage_rate >= 90 and len(missing) <= 1:
            score = 100
            message = f"完整（覆盖{len(covered)}/{len(key_events)} 个情节点）"
            passed = True
        elif coverage_rate >= 80 and len(missing) <= 2:
            score = 80
            message = f"较完整（覆盖{coverage_rate:.0f}%）"
            passed = True
        elif coverage_rate >= 60:
            score = 60
            message = f"有遗漏（缺失{len(missing)} 个情节点）"
            passed = False
        else:
            score = 30
            message = f"严重遗漏（仅覆盖{coverage_rate:.0f}%）"
            passed = False
        
        return {
            'score': score,
            'passed': passed,
            'message': message,
            'coverage_rate': round(coverage_rate, 1),
            'missing': missing,
            'covered': covered
        }
    
    def _check_readability(self, paraphrase: str) -> Dict[str, Any]:
        """
        可读性检查
        """
        score = 100
        
        # 检查段落结构
        paragraphs = [p for p in paraphrase.split('\n\n') if p.strip()]
        if len(paragraphs) < 5:
            score -= 20
        elif len(paragraphs) < 8:
            score -= 10
        
        # 检查连接词
        connectors = len(re.findall(r'然而 | 因此 | 但是 | 于是 | 随后 | 与此同时', paraphrase))
        if connectors < 3:
            score -= 15
        
        # 检查流畅性（简化：检查是否有重复句子）
        sentences = re.split(r'[。！？]', paraphrase)
        unique_sentences = set(sentences)
        if len(unique_sentences) < len(sentences) * 0.9:
            score -= 15
        
        message = f"可读性良好（{score}分）" if score >= 80 else f"可读性需改进（{score}分）"
        
        return {
            'score': max(0, score),
            'passed': score >= 80,
            'message': message
        }
    
    def _check_word_count_v2(self, paraphrase: str) -> Dict[str, Any]:
        """
        字数检查 v2.0（动态目标）
        """
        word_count = len(paraphrase)
        target = self.target_length
        tolerance = 200
        
        if target - tolerance <= word_count <= target + tolerance:
            score = 100
            message = f"字数合适（{word_count}字，目标{target}±{tolerance}字）"
            passed = True
        elif target - tolerance * 2 <= word_count <= target + tolerance * 2:
            score = 50
            message = f"字数偏差（{word_count}字，目标{target}±{tolerance}字）"
            passed = False
        else:
            score = 0
            message = f"字数严重不符（{word_count}字，目标{target}±{tolerance}字）"
            passed = False
        
        return {
            'score': score,
            'passed': passed,
            'message': message,
            'word_count': word_count,
            'target': target
        }


def test_checker_v2():
    """测试 v2.0 质检器"""
    
    # 测试短文（应该不通过）
    short_paraphrase = "池大为毕业了，去卫生厅工作。"
    
    # 测试抄袭（应该 0 分）
    plagiarism_paraphrase = "池大为研究生毕业后分配到省卫生厅工作。他满怀理想，想要在医学领域有所作为。"
    
    # 测试合格（应该通过）
    good_paraphrase = """
    1985 年，池大为从研究生毕业，被分配到省卫生厅工作。年轻人满怀抱负，想要在专业领域施展才华。
    
    报到第一天，池大为被安排到办公室，与丁小槐共事。丁小槐比他早来几年，精于人情世故，善于钻营；
    而池大为则保持着知识分子的清高与单纯，两人形成鲜明对比。
    
    工作中，池大为逐渐发现这里并非他想象中的专业天地。一份简单的文件流转，需要考虑的不仅是内容本身，
    还有层层递进的审批关系、各个部门的利益平衡，甚至领导们的个人喜好。
    
    一次会议上，池大为亲眼目睹了令他震撼的一幕：某个明显不合理的项目，因为符合某些人的利益，
    在众人的附和声中顺利通过。他忍不住提出质疑，却被丁小槐在会后悄悄提醒。
    
    这句话如当头棒喝。池大为开始反思自己之前的天真想法。他意识到，这个系统运行的逻辑与他所学的
    理论知识完全不同。书本上教的是是非对错，但现实中更多的是权衡和妥协。
    
    夜深人静时，池大为站在办公室窗前，望着城市的灯火，内心充满了矛盾。他不甘心就这样随波逐流，
    但又不知道如何坚持自己的原则。理想与现实的巨大落差，让他第一次真切地感受到了成长的阵痛。
    
    第一章结束时，池大为站在人生的十字路口。他明白自己必须做出选择：是坚守内心的信念，
    还是适应这个复杂的环境？从校园到官场的这段路，才刚刚开始。
    """
    
    source = [{'content': '池大为研究生毕业后分配到省卫生厅工作...'}]
    
    print("=== 测试短文（应该不通过）===")
    checker = StrictQualityCheckerV2(source, target_length=1800)
    result = checker.check_paraphrase(short_paraphrase)
    print(f"短文：{result['total_score']}分 - {'通过' if result['passed'] else '不通过'}")
    print(f"错误：{result['errors']}")
    
    print("\n=== 测试合格（应该通过）===")
    result = checker.check_paraphrase(good_paraphrase)
    print(f"合格：{result['total_score']}分 - {'通过' if result['passed'] else '不通过'}")
    print(f"各项得分：抄袭{result['plagiarism']['score']} 准确性{result['accuracy']['score']} 完整性{result['completeness']['score']} 可读性{result['readability']['score']} 字数{result['word_count']['score']}")


if __name__ == "__main__":
    test_checker_v2()
