#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
全书组装模块
功能：合并所有章节，跨章一致性检查，生成最终报告
"""

import json
from pathlib import Path
from typing import List, Dict, Any
from datetime import datetime


class BookAssembler:
    """全书组装器"""
    
    def __init__(self, output_dir: str):
        self.output_dir = Path(output_dir)
    
    def assemble(self, chapter_list: List[Dict[str, Any]]) -> Dict[str, Any]:
        """合并所有章节"""
        print("📚 开始合并全书...")
        
        full_book_parts = []
        passed_chapters = []
        manual_review_chapters = []
        consistency_errors = []
        
        for chapter_info in chapter_list:
            status = chapter_info.get('status', 'unknown')
            
            if status == 'passed':
                # 读取章节内容
                content = self._read_chapter(chapter_info['output_file'])
                if content:
                    full_book_parts.append(content)
                    passed_chapters.append(chapter_info)
            elif status == 'manual_review':
                manual_review_chapters.append(chapter_info)
        
        print(f"  通过章节：{len(passed_chapters)}")
        print(f"  待审核章节：{len(manual_review_chapters)}")
        
        # 跨章一致性检查
        print("  进行一致性检查...")
        consistency_errors = self._check_consistency(passed_chapters)
        
        # 生成全书
        full_book = self._generate_full_book(full_book_parts, chapter_list)
        
        # 生成报告
        report = self._generate_report(chapter_list, consistency_errors)
        
        # 保存
        self._save_outputs(full_book, report, consistency_errors)
        
        print("✅ 全书组装完成")
        
        return {
            'full_book_path': self.output_dir / 'full_book.md',
            'report_path': self.output_dir / 'quality_report.md',
            'passed_chapters': len(passed_chapters),
            'manual_review_chapters': len(manual_review_chapters),
            'consistency_errors': len(consistency_errors)
        }
    
    def _read_chapter(self, filepath: str) -> str:
        """读取章节内容"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            print(f"  ⚠️  读取失败：{filepath} - {e}")
            return None
    
    def _check_consistency(self, chapters: List[Dict]) -> List[str]:
        """跨章一致性检查"""
        errors = []
        
        # 1. 检查人物连续性
        all_characters = set()
        for chapter in chapters:
            content = self._read_chapter(chapter['output_file'])
            if content:
                # 提取人名（简化）
                import re
                names = re.findall(r'[张王李赵刘陈杨黄周吴徐孙朱马胡郭何高林罗郑梁谢宋唐韩冯邓曹彭曾萧田董袁潘于蒋蔡余杜叶程苏魏吕丁任沈姚卢姜崔钟谭陆汪范金石廖贾韦夏邱傅方邹熊孟秦白尹黎万段雷郝孔毛][\u4e00-\u9fa5]{1,2}', content)
                
                for name in names[:10]:
                    if name not in all_characters and all_characters:
                        # 新人物出现
                        pass
                    all_characters.add(name)
        
        # 2. 检查时间线
        # ...
        
        return errors
    
    def _generate_full_book(self, parts: List[str], chapter_list: List[Dict]) -> str:
        """生成全书"""
        header = f"""---
title: 三体第一部
total_chapters: {len(chapter_list)}
passed_chapters: {len([c for c in chapter_list if c.get('status') == 'passed'])}
manual_review_chapters: {len([c for c in chapter_list if c.get('status') == 'manual_review'])}
assembled_at: {datetime.now().isoformat()}
---

# 三体第一部 - 智能复述版

---

"""
        
        return header + '\n\n---\n\n'.join(parts)
    
    def _generate_report(self, chapter_list: List[Dict], consistency_errors: List[str]) -> str:
        """生成质量报告"""
        passed = [c for c in chapter_list if c.get('status') == 'passed']
        manual = [c for c in chapter_list if c.get('status') == 'manual_review']
        
        # 计算平均分
        avg_score = sum(c.get('quality_score', 0) for c in passed) / len(passed) if passed else 0
        
        report = f"""# 全书质量报告

**生成时间**: {datetime.now().isoformat()}

## 统计信息

- 总章节数：{len(chapter_list)}
- 通过章节：{len(passed)}
- 需审核章节：{len(manual)}
- 平均质量分：{avg_score:.1f}/100

## 质量等级分布

"""
        
        # 等级分布
        levels = {'S': 0, 'A': 0, 'B': 0, 'C': 0, 'D': 0}
        for chapter in passed:
            level = chapter.get('quality_level', 'C')
            if level in levels:
                levels[level] += 1
        
        for level, count in levels.items():
            report += f"- {level}级：{count} 章\n"
        
        report += f"""
## 需审核章节

"""
        
        for chapter in manual:
            report += f"- 第{chapter.get('chapter', '?')}章：{chapter.get('title', '')} (修订{chapter.get('retry_count', 0)}次)\n"
        
        report += f"""
## 一致性问题

"""
        
        if consistency_errors:
            for error in consistency_errors:
                report += f"- {error}\n"
        else:
            report += "✅ 未发现一致性问题\n"
        
        return report
    
    def _save_outputs(self, full_book: str, report: str, errors: List[str]):
        """保存输出"""
        # 全书
        with open(self.output_dir / 'full_book.md', 'w', encoding='utf-8') as f:
            f.write(full_book)
        print(f"  💾 已保存：full_book.md")
        
        # 质量报告
        with open(self.output_dir / 'quality_report.md', 'w', encoding='utf-8') as f:
            f.write(report)
        print(f"  💾 已保存：quality_report.md")
        
        # 一致性报告
        with open(self.output_dir / 'consistency_report.md', 'w', encoding='utf-8') as f:
            f.write("# 一致性报告\n\n")
            if errors:
                for error in errors:
                    f.write(f"- {error}\n")
            else:
                f.write("✅ 未发现一致性问题\n")
        print(f"  💾 已保存：consistency_report.md")


def main():
    """主函数"""
    # 测试
    chapter_list = [
        {'chapter': 1, 'status': 'passed', 'output_file': 'output/chapter_001.md', 'quality_score': 88},
        {'chapter': 2, 'status': 'passed', 'output_file': 'output/chapter_002.md', 'quality_score': 92},
        {'chapter': 3, 'status': 'manual_review', 'output_file': 'output/chapter_003.md', 'quality_score': 76},
    ]
    
    assembler = BookAssembler('output')
    result = assembler.assemble(chapter_list)
    
    print(f"\n✅ 组装完成：{result['passed_chapters']} 章通过")


if __name__ == "__main__":
    main()
