#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
输出目录管理器
功能：统一管理输出目录结构，支持多本书
"""

import os
import json
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime


class OutputManager:
    """输出目录管理器"""
    
    def __init__(self, book_title: str, workspace_dir: str = None):
        """
        初始化输出管理器
        
        Args:
            book_title: 书名（用于创建目录）
            workspace_dir: Workspace 根目录（默认为 /home/admin/openclaw/workspace/agents/Kyle/workspace）
        """
        self.book_title = self._sanitize_filename(book_title)
        
        # 获取 workspace 根目录
        if workspace_dir is None:
            # 默认：workspace 根目录
            workspace_dir = Path('/home/admin/openclaw/workspace/agents/Kyle/workspace')
        else:
            workspace_dir = Path(workspace_dir)
        
        # 输出目录：{workspace_dir}/novel-rag-{书名}/
        dir_name = f"novel-rag-{self.book_title}"
        self.output_dir = workspace_dir / dir_name
        
        # 子目录
        self.chapters_dir = self.output_dir / 'chapters'
        self.data_dir = self.output_dir / 'data'
        self.index_dir = self.output_dir / 'index'
        
        # 创建目录
        self._create_directories()
        
        # 元数据
        self.metadata = {
            'book_title': book_title,
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat(),
            'total_chapters': 0,
            'completed_chapters': 0,
            'status': 'initializing'
        }
        
        self._save_metadata()
        
        print(f"📁 输出目录已创建：{self.output_dir}")
        print(f"   位置：{workspace_dir}/novel-rag-{self.book_title}/")
        print(f"   - 章节目录：{self.chapters_dir}")
        print(f"   - 数据目录：{self.data_dir}")
        print(f"   - 索引目录：{self.index_dir}")
    
    def _sanitize_filename(self, filename: str) -> str:
        """清理文件名（移除非法字符）"""
        # 移除或替换非法字符
        illegal_chars = ['/', '\\', ':', '*', '?', '"', '<', '>', '|']
        for char in illegal_chars:
            filename = filename.replace(char, '_')
        
        # 限制长度
        if len(filename) > 100:
            filename = filename[:100]
        
        return filename.strip()
    
    def _create_directories(self):
        """创建目录结构"""
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.chapters_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.index_dir.mkdir(parents=True, exist_ok=True)
    
    def _save_metadata(self):
        """保存元数据"""
        metadata_path = self.output_dir / 'metadata.json'
        self.metadata['updated_at'] = datetime.now().isoformat()
        
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(self.metadata, f, ensure_ascii=False, indent=2)
    
    def save_chapter(self, chapter_num: int, content: str, 
                    quality_report: Optional[Dict] = None) -> Path:
        """
        保存章节文件
        
        Args:
            chapter_num: 章节号
            content: 章节内容
            quality_report: 质量报告（可选）
        
        Returns:
            文件路径
        """
        filename = f"chapter_{chapter_num:03d}.md"
        filepath = self.chapters_dir / filename
        
        # 添加元数据头
        header = f"""---
chapter: {chapter_num}
book: {self.metadata['book_title']}
generated_at: {datetime.now().isoformat()}
"""
        
        if quality_report:
            header += f"""quality_score: {quality_report.get('total', 0)}
quality_level: {quality_report.get('level', '?')}
status: {"passed" if quality_report.get('total', 0) >= 80 else "needs_review"}
"""
        
        header += "---\n\n"
        
        # 写入文件
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(header + content)
        
        # 更新元数据
        self.metadata['completed_chapters'] += 1
        self._save_metadata()
        
        print(f"  💾 已保存：{filepath}")
        return filepath
    
    def save_full_book(self, content: str) -> Path:
        """保存全书"""
        filepath = self.output_dir / 'full_book.md'
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print(f"  💾 已保存全书：{filepath}")
        return filepath
    
    def save_report(self, report_type: str, content: str) -> Path:
        """
        保存报告
        
        Args:
            report_type: 报告类型 (quality/global_quality/consistency)
            content: 报告内容
        
        Returns:
            文件路径
        """
        filename_map = {
            'quality': 'quality_report.md',
            'global_quality': 'global_quality_report.md',
            'consistency': 'consistency_report.md'
        }
        
        filename = filename_map.get(report_type, f'{report_type}_report.md')
        filepath = self.output_dir / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print(f"  💾 已保存报告：{filepath}")
        return filepath
    
    def save_index(self, index_data: Dict, index_name: str = 'written_index') -> Path:
        """保存索引"""
        filepath = self.index_dir / f'{index_name}.json'
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(index_data, f, ensure_ascii=False, indent=2)
        
        print(f"  💾 已保存索引：{filepath}")
        return filepath
    
    def save_data(self, data: Any, filename: str) -> Path:
        """保存数据文件"""
        filepath = self.data_dir / filename
        
        if isinstance(data, (dict, list)):
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        else:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(str(data))
        
        print(f"  💾 已保存数据：{filepath}")
        return filepath
    
    def get_chapter_path(self, chapter_num: int) -> Path:
        """获取章节文件路径"""
        return self.chapters_dir / f"chapter_{chapter_num:03d}.md"
    
    def list_chapters(self) -> list:
        """列出所有章节"""
        if not self.chapters_dir.exists():
            return []
        
        chapters = []
        for f in sorted(self.chapters_dir.glob('chapter_*.md')):
            # 提取章节号
            chapter_num = int(f.stem.split('_')[1])
            chapters.append({
                'number': chapter_num,
                'path': f,
                'size': f.stat().st_size
            })
        
        return chapters
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        chapters = self.list_chapters()
        
        return {
            'book_title': self.metadata['book_title'],
            'output_dir': str(self.output_dir),
            'total_chapters': len(chapters),
            'completed_chapters': self.metadata.get('completed_chapters', 0),
            'total_size': sum(ch['size'] for ch in chapters),
            'created_at': self.metadata.get('created_at', ''),
            'updated_at': self.metadata.get('updated_at', '')
        }
    
    def generate_summary(self) -> str:
        """生成输出摘要"""
        stats = self.get_statistics()
        
        summary = f"""# 输出目录摘要

**书名**: {stats['book_title']}
**输出目录**: {stats['output_dir']}
**创建时间**: {stats['created_at']}
**更新时间**: {stats['updated_at']}

## 统计信息
- 总章节数：{stats['total_chapters']}
- 已完成章节：{stats['completed_chapters']}
- 总大小：{stats['total_size'] / 1024:.1f} KB

## 目录结构
```
{stats['output_dir']}/
├── chapters/           # 章节文件
├── data/              # 数据文件
├── index/             # 索引文件
├── full_book.md       # 全书
├── quality_report.md  # 质量报告
└── metadata.json      # 元数据
```

## 章节列表
"""
        
        for ch in chapters[:10]:
            summary += f"- 第{ch['number']:03d}章：{ch['path'].name} ({ch['size'] / 1024:.1f} KB)\n"
        
        if len(chapters) > 10:
            summary += f"- ... 还有 {len(chapters) - 10} 章\n"
        
        return summary
    
    def finalize(self):
        """完成输出，更新状态"""
        self.metadata['status'] = 'completed'
        self._save_metadata()
        
        # 生成摘要
        summary = self.generate_summary()
        summary_path = self.output_dir / 'README.md'
        
        with open(summary_path, 'w', encoding='utf-8') as f:
            f.write(summary)
        
        print(f"\n✅ 输出完成！")
        print(f"📁 目录：{self.output_dir}")
        print(f"📄 摘要：{summary_path}")


def main():
    """测试"""
    # 创建输出管理器
    manager = OutputManager('三体第一部')
    
    # 保存章节
    manager.save_chapter(1, "第一章内容...", {'total': 85, 'level': 'A'})
    manager.save_chapter(2, "第二章内容...", {'total': 90, 'level': 'S'})
    manager.save_chapter(3, "第三章内容...", {'total': 78, 'level': 'B'})
    
    # 保存全书
    manager.save_full_book("# 三体第一部\n\n...全书内容...")
    
    # 保存报告
    manager.save_report('quality', "# 质量报告\n\n...")
    
    # 保存索引
    manager.save_index({'concepts': ['汪淼', '史强']}, 'written_index')
    
    # 完成
    manager.finalize()
    
    # 查看统计
    print("\n📊 统计信息:")
    stats = manager.get_statistics()
    for k, v in stats.items():
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
