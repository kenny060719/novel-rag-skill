#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
全局质检模块 - Phase 3
功能：覆盖率检查、重复度检查、连贯性检查
"""

import json
from pathlib import Path
from typing import List, Dict, Any, Tuple
from datetime import datetime


class GlobalQualityChecker:
    """全局质检器"""
    
    def __init__(self, written_index):
        self.written_index = written_index
    
    def check_all(self, chapter_list: List[Dict]) -> Dict[str, Any]:
        """
        Phase 3: 全局质检
        - 覆盖率检查
        - 重复度检查
        - 连贯性检查
        """
        print("\n" + "="*60)
        print("📊 Phase 3: 全局质检")
        print("="*60)
        
        # 1. 覆盖率检查
        print("\n  1️⃣ 覆盖率检查...")
        coverage_report = self._check_coverage(chapter_list)
        
        # 2. 重复度检查
        print("  2️⃣ 重复度检查...")
        duplicate_report = self._check_duplicates(chapter_list)
        
        # 3. 连贯性检查
        print("  3️⃣ 连贯性检查...")
        coherence_report = self._check_coherence(chapter_list)
        
        # 4. 生成总报告
        total_report = self._generate_total_report(
            coverage_report,
            duplicate_report,
            coherence_report
        )
        
        # 5. 保存报告
        self._save_report(total_report)
        
        print("\n✅ 全局质检完成")
        print(f"  覆盖率：{coverage_report['average_rate']}%")
        print(f"  重复率：{duplicate_report['duplicate_rate']}%")
        print(f"  连贯性：{coherence_report['score']}/100")
        
        return total_report
    
    def _check_coverage(self, chapter_list: List[Dict]) -> Dict[str, Any]:
        """覆盖率检查"""
        chapter_reports = []
        total_coverage = 0
        
        for chapter in chapter_list:
            chapter_num = chapter.get('chapter_number', 0)
            source_concepts = chapter.get('source_concepts', [])
            written_concepts = self.written_index.get_chapter_concepts(chapter_num)
            
            coverage = self.written_index.check_coverage(
                chapter_num, source_concepts, written_concepts
            )
            
            chapter_reports.append(coverage)
            total_coverage += coverage['coverage_rate']
        
        average_rate = total_coverage / len(chapter_list) if chapter_list else 0
        
        # 找出覆盖率低的章节
        low_coverage_chapters = [
            r for r in chapter_reports 
            if r['coverage_rate'] < 80
        ]
        
        report = {
            'chapters': chapter_reports,
            'average_rate': round(average_rate, 1),
            'low_coverage_chapters': low_coverage_chapters,
            'passed': len(low_coverage_chapters) == 0
        }
        
        print(f"     平均覆盖率：{average_rate:.1f}%")
        print(f"     低覆盖率章节：{len(low_coverage_chapters)} 个")
        
        return report
    
    def _check_duplicates(self, chapter_list: List[Dict]) -> Dict[str, Any]:
        """重复度检查"""
        total_paragraphs = 0
        duplicate_paragraphs = 0
        
        for chapter in chapter_list:
            content = chapter.get('content', '')
            paragraphs = content.split('\n\n')
            total_paragraphs += len(paragraphs)
            
            for para in paragraphs:
                if para.strip():
                    is_dup, _ = self.written_index.check_duplicate(para)
                    if is_dup:
                        duplicate_paragraphs += 1
        
        duplicate_rate = (duplicate_paragraphs / total_paragraphs * 100 
                         if total_paragraphs > 0 else 0)
        
        stats = self.written_index.get_statistics()
        
        report = {
            'total_paragraphs': total_paragraphs,
            'duplicate_paragraphs': duplicate_paragraphs,
            'duplicate_rate': round(duplicate_rate, 1),
            'passed': duplicate_rate < 5
        }
        
        print(f"     总段落数：{total_paragraphs}")
        print(f"     重复段落：{duplicate_paragraphs}")
        print(f"     重复率：{duplicate_rate:.1f}%")
        
        return report
    
    def _check_coherence(self, chapter_list: List[Dict]) -> Dict[str, Any]:
        """连贯性检查"""
        coherence_issues = []
        
        # 检查章节衔接
        for i in range(len(chapter_list) - 1):
            current_ch = chapter_list[i]
            next_ch = chapter_list[i + 1]
            
            # 检查人物连续性
            current_chars = set(current_ch.get('characters', []))
            next_chars = set(next_ch.get('characters', []))
            
            # 检查时间线
            current_time = current_ch.get('time', '')
            next_time = next_ch.get('time', '')
            
            # 简化检查
            if not current_chars & next_chars:
                coherence_issues.append({
                    'type': '人物断层',
                    'chapters': [i+1, i+2],
                    'description': f'第{i+1}章和第{i+2}章之间人物无交集'
                })
        
        coherence_score = 100 - len(coherence_issues) * 10
        
        report = {
            'issues': coherence_issues,
            'score': max(0, coherence_score),
            'passed': len(coherence_issues) == 0
        }
        
        print(f"     连贯性问题：{len(coherence_issues)} 个")
        print(f"     连贯性评分：{coherence_score}/100")
        
        return report
    
    def _generate_total_report(self, coverage: Dict, duplicate: Dict, 
                              coherence: Dict) -> Dict[str, Any]:
        """生成总报告"""
        # 计算综合评分
        total_score = (
            coverage['average_rate'] * 0.4 +
            (100 - duplicate['duplicate_rate']) * 0.3 +
            coherence['score'] * 0.3
        )
        
        # 判断是否通过
        passed = (
            coverage['passed'] and 
            duplicate['passed'] and 
            coherence['passed']
        )
        
        report = {
            'generated_at': datetime.now().isoformat(),
            'total_score': round(total_score, 1),
            'passed': passed,
            'coverage': coverage,
            'duplicate': duplicate,
            'coherence': coherence,
            'summary': self._generate_summary(coverage, duplicate, coherence)
        }
        
        return report
    
    def _generate_summary(self, coverage: Dict, duplicate: Dict, 
                         coherence: Dict) -> str:
        """生成总结"""
        summary = "# 全局质检总结\n\n"
        
        if coverage['passed'] and duplicate['passed'] and coherence['passed']:
            summary += "✅ **所有检查通过！**\n\n"
        else:
            summary += "⚠️ **存在以下问题：**\n\n"
            
            if not coverage['passed']:
                summary += f"- 覆盖率不足：{len(coverage['low_coverage_chapters'])} 章低于 80%\n"
            
            if not duplicate['passed']:
                summary += f"- 重复率过高：{duplicate['duplicate_rate']}%\n"
            
            if not coherence['passed']:
                summary += f"- 连贯性问题：{len(coherence['issues'])} 个\n"
        
        summary += f"\n## 评分详情\n\n"
        summary += f"- 覆盖率：{coverage['average_rate']}% (权重 40%)\n"
        summary += f"- 重复率：{duplicate['duplicate_rate']}% (权重 30%)\n"
        summary += f"- 连贯性：{coherence['score']}/100 (权重 30%)\n"
        
        return summary
    
    def _save_report(self, report: Dict):
        """保存报告"""
        output_path = Path('output/global_quality_report.md')
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        md_content = f"""# 全局质检报告

**生成时间**: {report['generated_at']}

## 总评

**综合评分**: {report['total_score']}/100
**通过状态**: {"✅ 通过" if report['passed'] else "❌ 未通过"}

{report['summary']}

---

## 覆盖率详情

| 章节 | 源概念数 | 已写概念数 | 覆盖率 | 状态 |
|------|---------|-----------|--------|------|
"""
        
        for ch_report in report['coverage']['chapters'][:10]:
            status = "✅" if ch_report['passed'] else "⚠️"
            md_content += (
                f"| 第{ch_report['chapter']}章 | "
                f"{ch_report['source_concepts']} | "
                f"{ch_report['written_concepts']} | "
                f"{ch_report['coverage_rate']}% | {status} |\n"
            )
        
        if len(report['coverage']['chapters']) > 10:
            md_content += f"| ... | ... | ... | ... | ... |\n"
        
        md_content += f"""
---

## 重复度详情

- 总段落数：{report['duplicate']['total_paragraphs']}
- 重复段落：{report['duplicate']['duplicate_paragraphs']}
- 重复率：{report['duplicate']['duplicate_rate']}%

---

## 连贯性问题

"""
        
        if report['coherence']['issues']:
            for issue in report['coherence']['issues'][:5]:
                md_content += (
                    f"- **{issue['type']}**: 第{issue['chapters'][0]}-{issue['chapters'][1]}章\n"
                    f"  {issue['description']}\n\n"
                )
        else:
            md_content += "✅ 无连贯性问题\n"
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(md_content)
        
        print(f"  💾 报告已保存：{output_path}")


def main():
    """测试"""
    from written_index import WrittenIndex
    
    # 创建索引
    written_index = WrittenIndex('output/test_written_index.json')
    
    # 创建质检器
    checker = GlobalQualityChecker(written_index)
    
    # 测试章节列表
    chapter_list = [
        {
            'chapter_number': 1,
            'source_concepts': ['汪淼', '史强', '科学边界'],
            'content': '汪淼觉得...'
        },
        {
            'chapter_number': 2,
            'source_concepts': ['丁仪', '台球', '物理学'],
            'content': '推开丁仪...'
        },
        {
            'chapter_number': 3,
            'source_concepts': ['汪淼', '宇宙闪烁', '倒计时'],
            'content': '汪淼看到...'
        }
    ]
    
    # 运行质检
    report = checker.check_all(chapter_list)
    
    print(f"\n✅ 质检完成")
    print(f"  总分：{report['total_score']}/100")
    print(f"  通过：{report['passed']}")


if __name__ == "__main__":
    main()
