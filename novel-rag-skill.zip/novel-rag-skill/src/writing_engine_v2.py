#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
写作引擎 v2 - 支持双层检索 + 防重复
"""

import json
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime


class WritingEngineV2:
    """写作引擎 v2 - 支持双层检索和防重复"""
    
    def __init__(self, config: Dict[str, Any], retriever=None, 
                 written_index=None, style_prompt: str = ""):
        self.config = config
        self.retriever = retriever
        self.written_index = written_index
        self.style_prompt = style_prompt
        self.max_retries = config.get('writing', {}).get('max_retries', 3)
        self.word_count_target = config.get('writing', {}).get('word_count_target', 1000)
    
    def write_chapter(self, chapter_num: int, chapter_info: Dict, 
                     source_chunks: List[Dict]) -> Dict[str, Any]:
        """
        Phase 2: 逐章撰写
        流程：检索 → 查重 → 撰写 → 评分 → 修改 → 定稿
        """
        print(f"\n{'='*60}")
        print(f"✍️  第{chapter_num}章：{chapter_info.get('title', '')}")
        print(f"{'='*60}")
        
        # Step 1: 双层检索
        print("  🔍 双层检索...")
        chapter_contexts = self._retrieve_chapter_contexts(chapter_num, chapter_info)
        global_contexts = self._retrieve_global_contexts(chapter_num)
        
        # Step 2: 查重检查
        print("  🔎 查重检查...")
        duplicate_report = self._check_duplicates(chapter_contexts)
        
        # Step 3: 提取关键概念
        print("  📋 提取关键概念...")
        from written_index import ConceptExtractor
        extractor = ConceptExtractor()
        source_concepts = extractor.extract_from_chunks(source_chunks)
        print(f"     源概念：{len(source_concepts)} 个")
        
        # Step 4: 写作循环（最多 3 次）
        success = False
        draft = None
        quality = None
        
        for retry in range(self.max_retries):
            print(f"\n  ✍️  写作尝试 {retry + 1}/{self.max_retries}")
            
            # 生成初稿
            draft = self._generate_draft(
                chapter_num=chapter_num,
                chapter_info=chapter_info,
                chapter_contexts=chapter_contexts,
                global_contexts=global_contexts,
                source_concepts=source_concepts
            )
            
            # 五维评分
            quality = self._evaluate_quality(draft, source_chunks, source_concepts)
            print(f"  📊 质量评分：{quality['total']}/100 ({quality['level']}级)")
            print(f"     结构：{quality['scores']['结构']}")
            print(f"     论点：{quality['scores']['论点']}")
            print(f"     论据：{quality['scores']['论据']}")
            print(f"     洞见：{quality['scores']['洞见']}")
            print(f"     适用：{quality['scores']['适用性']}")
            
            # 判断是否通过
            if quality['total'] >= 80:
                print(f"  ✅ 质量达标")
                success = True
                break
            else:
                print(f"  ⚠️  质量不达标，准备修订")
                draft = self._revise_draft(draft, quality, chapter_contexts)
        
        if not success:
            print(f"  ❌ 修订{self.max_retries}次仍不合格，标记需人工审核")
        
        # Step 5: 定稿并更新索引
        if draft:
            print("  💾 定稿并更新全局索引...")
            self._finalize_chapter(chapter_num, draft, source_concepts)
        
        return {
            'success': success,
            'chapter': chapter_num,
            'draft': draft,
            'quality': quality,
            'duplicate_report': duplicate_report,
            'source_concepts': source_concepts
        }
    
    def _retrieve_chapter_contexts(self, chapter_num: int, 
                                   chapter_info: Dict) -> List[Dict]:
        """检索本章相关内容"""
        if not self.retriever:
            return []
        
        query = f"{chapter_info.get('title', '')} " + \
                f"{' '.join(chapter_info.get('metadata', {}).get('main_characters', []))}"
        
        # 限定章节范围检索
        contexts = self.retriever.search(
            query=query,
            top_k=15,
            filters={'chapter_range': (chapter_num, chapter_num)}
        )
        
        print(f"     本章检索：{len(contexts)} 个片段")
        return contexts
    
    def _retrieve_global_contexts(self, chapter_num: int) -> List[Dict]:
        """检索全局已写内容（防重复）"""
        if not self.written_index:
            return []
        
        # 获取已写概念
        written_concepts = []
        for ch in range(1, chapter_num):
            written_concepts.extend(self.written_index.get_chapter_concepts(ch))
        
        # 检索相关已写内容
        # TODO: 实现已写内容检索
        
        print(f"     全局检索：{len(written_concepts)} 个已写概念")
        return []
    
    def _check_duplicates(self, contexts: List[Dict]) -> Dict[str, Any]:
        """检查重复"""
        duplicate_count = 0
        
        for ctx in contexts:
            content = ctx.get('chunk', {}).get('content', '')
            if self.written_index:
                is_dup, score = self.written_index.check_duplicate(content)
                if is_dup:
                    duplicate_count += 1
        
        return {
            'total_chunks': len(contexts),
            'duplicate_chunks': duplicate_count,
            'duplicate_rate': duplicate_count / len(contexts) * 100 if contexts else 0
        }
    
    def _generate_draft(self, chapter_num: int, chapter_info: Dict,
                       chapter_contexts: List[Dict], global_contexts: List[Dict],
                       source_concepts: List[str]) -> Dict[str, Any]:
        """生成初稿"""
        # 构建提示词
        prompt = self._build_prompt(
            chapter_num=chapter_num,
            chapter_info=chapter_info,
            chapter_contexts=chapter_contexts,
            global_contexts=global_contexts,
            source_concepts=source_concepts
        )
        
        # 调用 LLM 生成
        content = self._call_llm(prompt)
        
        return {
            'content': content,
            'chapter': chapter_num,
            'word_count': len(content),
            'generated_at': datetime.now().isoformat()
        }
    
    def _build_prompt(self, chapter_num: int, chapter_info: Dict,
                     chapter_contexts: List[Dict], global_contexts: List[Dict],
                     source_concepts: List[str]) -> str:
        """构建提示词"""
        prompt = f"""
你是专业的小说复述助手，请严格遵守以下规则：

【绝对禁止】🚫
❌ 绝不编造原著没有的人物、对话、心理活动、场景
❌ 绝不混淆时间线或人物关系
❌ 绝不添加原著没有的细节

【必须执行】✅
✅ 只基于提供的检索内容进行复述
✅ 每段复述后必须标注引用位置：[引用：第 X 章 第 Y 段]
✅ 遇到模糊内容，明确写"原文未明确说明，待核实"
✅ 保持时间线一致，不颠倒事件顺序
✅ 覆盖提供的关键概念

【本章信息】
- 章节：第{chapter_num}章 {chapter_info.get('title', '')}
- 关键概念：{', '.join(source_concepts[:10])}

【本章检索内容】
{self._format_contexts(chapter_contexts)}

【全局已写内容】（避免重复）
{self._format_contexts(global_contexts)}

【写作风格要求】
{self.style_prompt}

开始复述：
"""
        return prompt
    
    def _format_contexts(self, contexts: List[Dict]) -> str:
        """格式化检索内容"""
        if not contexts:
            return "无"
        
        formatted = []
        for i, ctx in enumerate(contexts[:10], 1):
            chunk = ctx.get('chunk', {})
            formatted.append(f"""
【片段{i}】
[引用：第{chunk.get('chapter', '?')}章 第{chunk.get('paragraph', '?')}段]
{chunk.get('content', '')[:200]}
---
""")
        
        return '\n'.join(formatted)
    
    def _call_llm(self, prompt: str) -> str:
        """调用 OpenClaw LLM 生成（方式一：使用 openclaw_llm 模块）"""
        print("    调用 OpenClaw LLM 生成...")
        
        try:
            # 使用 openclaw_llm 模块
            from openclaw_llm import OpenClawLLM
            
            llm = OpenClawLLM(self.config)
            content = llm.generate(prompt)
            
            if content and len(content) > 100:
                print(f"    ✅ OpenClaw LLM 生成成功：{len(content)} 字")
                return content
            else:
                print("    ⚠️  OpenClaw LLM 返回内容过短，使用模拟内容")
                return self._mock_generate(prompt)
            
        except ImportError as e:
            print(f"    ⚠️  openclaw_llm 不可用：{e}")
            return self._mock_generate(prompt)
        except Exception as e:
            print(f"    ⚠️  LLM 调用失败：{e}")
            return self._mock_generate(prompt)
    
    def _mock_generate(self, prompt: str) -> str:
        """模拟生成（临时使用）"""
        # 从提示词提取章节信息
        if "第 1 章" in prompt or "空手套白狼" in prompt:
            return self._generate_zhangduo_ch1()
        elif "第 2 章" in prompt or "珍珑棋局" in prompt:
            return self._generate_zhangduo_ch2()
        else:
            return "内容生成中..."
    
    def _generate_zhangduo_ch1(self) -> str:
        """生成掌舵第 1 章内容"""
        return """# 第 1 章 空手套白狼

市委大院的清晨总是格外安静。

[引用：第 1 章 第 1 段]

胡一伟站在阳台上，手里端着一杯热茶，目光穿过薄雾，落在远处正在建设中的开发区上。作为湖州市委副书记，他肩上的担子不轻。

[引用：第 1 章 第 3 段]

"胡书记，早啊。"妻子林雪从屋里走出来，手里拿着一份报纸，"今天有个重要会议吧？"

[引用：第 1 章 第 5 段]

胡一伟点点头，没有说话。他的心思还在那份刚送来的开发区规划方案上。这个项目关系到湖州市未来五年的发展，容不得半点闪失。

[引用：第 1 章 第 8 段]

...

【引用来源汇总】
- 第 1 章 第 1 段
- 第 1 章 第 3 段
- 第 1 章 第 5 段
- 第 1 章 第 8 段
"""
    
    def _generate_zhangduo_ch2(self) -> str:
        """生成掌舵第 2 章内容"""
        return """# 第 2 章 珍珑棋局

会议室里的气氛有些凝重。

[引用：第 2 章 第 1 段]

胡一伟坐在长桌尽头，面前摆着一份厚厚的文件。在座的都是市委、市政府的班子成员，每个人的表情都很严肃。

[引用：第 2 章 第 3 段]

"开发区的事情，大家有什么看法？"胡一伟打破了沉默。

[引用：第 2 章 第 5 段]

没有人立即回答。这个问题太敏感了，涉及到多方利益，谁都不想第一个表态。

[引用：第 2 章 第 8 段]

...

【引用来源汇总】
- 第 2 章 第 1 段
- 第 2 章 第 3 段
- 第 2 章 第 5 段
- 第 2 章 第 8 段
"""
    
    def _evaluate_quality(self, draft: Dict, source_chunks: List[Dict], 
                         source_concepts: List[str]) -> Dict[str, Any]:
        """五维质量评分"""
        content = draft.get('content', '')
        
        # 维度 1: 结构（15 分）
        structure_score = self._evaluate_structure(content)
        
        # 维度 2: 论点（20 分）
        argument_score = self._evaluate_arguments(content)
        
        # 维度 3: 论据（25 分）
        evidence_score = self._evaluate_evidence(content, source_chunks)
        
        # 维度 4: 洞见（20 分）
        insight_score = self._evaluate_insights(content)
        
        # 维度 5: 适用性（20 分）
        applicability_score = self._evaluate_applicability(content)
        
        # 加权总分
        total = (
            structure_score * 0.15 +
            argument_score * 0.20 +
            evidence_score * 0.25 +
            insight_score * 0.20 +
            applicability_score * 0.20
        )
        
        # 确定等级
        level = self._get_level(total)
        
        return {
            'scores': {
                '结构': round(structure_score, 1),
                '论点': round(argument_score, 1),
                '论据': round(evidence_score, 1),
                '洞见': round(insight_score, 1),
                '适用性': round(applicability_score, 1)
            },
            'total': round(total, 1),
            'level': level,
            'errors': [],
            'suggestions': []
        }
    
    def _evaluate_structure(self, content: str) -> float:
        """结构评分"""
        # 检查是否有清晰的段落结构
        paragraphs = content.split('\n\n')
        if len(paragraphs) >= 5:
            return 90
        elif len(paragraphs) >= 3:
            return 75
        else:
            return 60
    
    def _evaluate_arguments(self, content: str) -> float:
        """论点评分"""
        # 检查是否有明确的主题句
        if '首先' in content or '第一' in content:
            return 85
        return 75
    
    def _evaluate_evidence(self, content: str, source_chunks: List[Dict]) -> float:
        """论据评分"""
        # 检查引用标注
        citation_count = content.count('[引用：')
        if citation_count >= 5:
            return 90
        elif citation_count >= 3:
            return 75
        else:
            return 60
    
    def _evaluate_insights(self, content: str) -> float:
        """洞见评分"""
        # 检查是否有金句或重点
        if '真实' in content or '扎心' in content:
            return 85
        return 75
    
    def _evaluate_applicability(self, content: str) -> float:
        """适用性评分"""
        # 检查是否有行动建议或总结
        if '建议' in content or '总结' in content:
            return 85
        return 75
    
    def _get_level(self, score: float) -> str:
        """评分等级"""
        if score >= 90: return 'S'
        elif score >= 80: return 'A'
        elif score >= 70: return 'B'
        elif score >= 60: return 'C'
        else: return 'D'
    
    def _revise_draft(self, draft: Dict, quality: Dict, 
                     contexts: List[Dict]) -> Dict[str, Any]:
        """修订初稿"""
        # 简化实现：重新生成
        content = self._call_llm("修订：" + draft.get('content', '')[:500])
        return {
            'content': content,
            'chapter': draft.get('chapter', 0),
            'word_count': len(content),
            'generated_at': datetime.now().isoformat()
        }
    
    def _finalize_chapter(self, chapter_num: int, draft, 
                         concepts: List[str]):
        """定稿并更新索引"""
        if not self.written_index:
            return
        
        # 提取段落（draft 可能是 string 或 dict）
        if isinstance(draft, dict):
            content = draft.get('content', '')
        else:
            content = str(draft)
        paragraphs = content.split('\n\n')
        
        # 更新全局索引
        self.written_index.finalize_chapter(
            chapter_num=chapter_num,
            concepts=concepts,
            paragraphs=paragraphs
        )


def main():
    """测试"""
    print("写作引擎 v2 测试")
    
    # 创建索引
    from written_index import WrittenIndex
    written_index = WrittenIndex('output/test_written_index.json')
    
    # 创建写作引擎
    engine = WritingEngineV2(
        config={},
        written_index=written_index,
        style_prompt="冷静客观的语调"
    )
    
    # 测试写作
    chapter_info = {
        'title': '宇宙闪烁',
        'metadata': {'main_characters': ['汪淼', '史强']}
    }
    
    source_chunks = []
    
    result = engine.write_chapter(3, chapter_info, source_chunks)
    
    print(f"\n✅ 写作完成")
    print(f"  成功：{result['success']}")
    print(f"  质量：{result['quality']['total']}/100")
    print(f"  概念：{len(result['source_concepts'])} 个")


if __name__ == "__main__":
    main()
