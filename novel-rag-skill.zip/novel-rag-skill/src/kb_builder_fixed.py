#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
知识库构建模块 - 修复版
功能：从切分片段中提取人物、时间线、概念、地点，构建结构化知识库
修复：人物抽取错误、概念集为空的问题
"""

import re
import json
from pathlib import Path
from typing import List, Dict, Any
from datetime import datetime
from collections import defaultdict


# 停用词表
STOPWORDS = set([
    '的', '了', '是', '在', '我', '有', '这', '那', '他', '她', '它',
    '一个', '这个', '那个', '什么', '怎么', '为什么', '如何',
    '自己', '别人', '大家', '我们', '你们', '他们'
])

# 排除常见非人名词汇（即使以姓氏开头）
EXCLUDE_WORDS = set([
    '马上', '应该', '成为', '方面', '干什么', '平时', '经常',
    '时间', '强烈', '时候', '路上', '明白', '任何', '高中', '何况', '毕业',
    '危险', '家里', '房子', '安排', '屈原', '曹雪芹',  # 历史人物，非本书角色
    '明确', '常常', '方式', '任性', '干事', '谢谢', '明显', '明年', '解释',
    '明天', '房中', '高贵', '房间', '平民', '安慰', '计较', '何以堪', '陶渊明'
])

# 排除后缀（用于过滤非人名）
EXCLUDE_SUFFIXES = [
    '书', '像', '画', '诗', '词', '曲', '戏', '剧', '电影',
    '省', '市', '县', '区', '镇', '村', '路', '街', '道',
    '局', '厅', '部', '司', '处', '科', '所', '站',
    '公司', '学校', '医院', '工厂', '单位', '组织',
    '先生', '老师', '同志', '书记', '主任', '处长', '科长'
]

# 常见姓氏（用于人名识别）
SURNAMES = set('赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜戚谢邹喻柏水窦章云苏潘葛奚范彭郎鲁韦昌马苗凤花方俞任袁柳酆鲍史唐费廉岑薛雷贺倪汤滕殷罗毕郝邬安常乐于时傅皮卡齐康伍余元卜顾孟平黄和穆萧尹姚邵湛汪祁毛禹狄米贝明臧计伏成戴谈宋茅庞熊纪舒屈项祝董梁杜阮蓝闵席季麻强贾路娄危江童颜郭梅盛林刁钟徐邱骆高夏蔡田樊胡凌霍虞万支柯昝管卢莫经房裘缪干解应宗丁宣邓郁单杭洪包诸左石崔吉钮龚程嵇邢滑裴陆荣翁荀羊於惠甄曲家封芮羿储靳汲邴糜松井卞樊赖池晏耿')


class KnowledgeBaseBuilder:
    """知识库构建器（修复版）"""
    
    def __init__(self):
        self.characters = {}  # 人物志
        self.timeline = []    # 时间线
        self.concepts = {}    # 概念集
        self.locations = {}   # 地点集
        self.events = {}      # 事件集
        
        # 加载自定义人名词典（解决 jieba 分词问题）
        self._load_custom_names()
    
    def _load_custom_names(self):
        """加载自定义人名到 jieba 词典"""
        try:
            import jieba
            # 沧浪之水主要人物
            custom_names = [
                '池大为', '董柳', '马垂章', '马厅长', '池一波', '晏之鹤',
                '孙之华', '耿院长', '舒少华', '沈姨', '小莫', '黄处长',
                '吴处长', '丁主任', '董父', '董母'
            ]
            for name in custom_names:
                jieba.add_word(name)
        except:
            pass
    
    def build_from_chunks(self, chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """从切分片段构建知识库"""
        print("📚 开始构建知识库...")
        
        # 1. 人物抽取
        print("  抽取人物信息...")
        self.characters = self._extract_characters(chunks)
        
        # 2. 时间线构建
        print("  构建时间线...")
        self.timeline = self._build_timeline(chunks)
        
        # 3. 概念抽取
        print("  抽取概念...")
        self.concepts = self._extract_concepts(chunks)
        
        # 4. 地点抽取
        print("  抽取地点...")
        self.locations = self._extract_locations(chunks)
        
        # 5. 事件抽取
        print("  抽取事件...")
        self.events = self._extract_events(chunks)
        
        print("✅ 知识库构建完成")
        
        return self.export()
    
    def _extract_characters(self, chunks: List[Dict]) -> Dict[str, Dict]:
        """
        提取人物信息（修复版）
        使用 jieba 分词 + 规则过滤
        """
        try:
            import jieba
        except ImportError:
            print("  ⚠️  jieba 未安装，使用简化模式")
            return self._extract_characters_simple(chunks)
        
        characters = {}
        
        for chunk in chunks:
            content = chunk['content']
            chapter = chunk['chapter']
            
            # 分词
            words = jieba.lcut(content)
            
            # 过滤可能是人名的词
            for word in words:
                # 长度检查（2-3 个字）
                if len(word) < 2 or len(word) > 3:
                    continue
                
                # 排除停用词
                if word in STOPWORDS:
                    continue
                
                # 排除带排除后缀的词
                if any(word.endswith(s) for s in EXCLUDE_SUFFIXES):
                    continue
                
                # 排除纯数字、标点（至少包含一个中文字符）
                if word.isdigit() or not any('\u4e00' <= c <= '\u9fa5' for c in word):
                    continue
                
                # 排除常见非人名模式
                if any(x in word for x in ['的', '了', '是', '在', '有']):
                    continue
                
                # 排除已知非人名词汇
                if word in EXCLUDE_WORDS:
                    continue
                
                # 姓氏检查：首字必须是常见姓氏（减少误判）
                if word[0] not in SURNAMES:
                    continue
                
                # 添加到人物列表
                if word not in characters:
                    characters[word] = {
                        'name': word,
                        'first_appearance': chapter,
                        'appearances': [chapter],
                        'total_count': 1,  # 总出现次数
                        'identity': self._guess_identity(word, content),
                        'relations': [],
                        'key_events': []
                    }
                else:
                    characters[word]['appearances'].append(chapter)
                    characters[word]['total_count'] += 1
        
        # 过滤：只保留总出现 3 次以上的人物（减少误判）
        filtered = {k: v for k, v in characters.items() if v['total_count'] >= 3}
        
        print(f"    识别人物：{len(filtered)} 个（原始：{len(characters)} 个）")
        
        return filtered
    
    def _extract_characters_simple(self, chunks: List[Dict]) -> Dict[str, Dict]:
        """简化版人物抽取（不使用 jieba）"""
        characters = {}
        
        # 常见人名姓氏
        surnames = '赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜戚谢邹喻柏水窦章云苏潘葛奚范彭郎鲁韦昌马苗凤花方俞任袁柳酆鲍史唐费廉岑薛雷贺倪汤滕殷罗毕郝邬安常乐于时傅皮卡齐康伍余元卜顾孟平黄和穆萧尹姚邵湛汪祁毛禹狄米贝明臧计伏成戴谈宋茅庞熊纪舒屈项祝董梁杜阮蓝闵席季麻强贾路娄危江童颜郭梅盛林刁钟徐邱骆高夏蔡田樊胡凌霍虞万支柯昝管卢莫经房裘缪干解应宗丁宣邓郁单杭洪包诸左石崔吉钮龚程嵇邢滑裴陆荣翁荀羊於惠甄曲家封芮羿储靳汲邴糜松井卞樊赖湛汪'
        
        for chunk in chunks:
            content = chunk['content']
            chapter = chunk['chapter']
            
            # 查找 2-3 字的人名模式
            pattern = r'([赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜戚谢邹喻柏水窦章云苏潘葛奚范彭郎鲁韦昌马苗凤花方俞任袁柳酆鲍史唐费廉岑薛雷贺倪汤滕殷罗毕郝邬安常乐于时傅皮卡齐康伍余元卜顾孟平黄和穆萧尹姚邵湛汪祁毛禹狄米贝明臧计伏成戴谈宋茅庞熊纪舒屈项祝董梁杜阮蓝闵席季麻强贾路娄危江童颜郭梅盛林刁钟徐邱骆高夏蔡田樊胡凌霍虞万支柯昝管卢莫经房裘缪干解应宗丁宣邓邓郁单杭洪包诸左石崔吉钮龚程嵇邢滑裴陆荣翁荀羊於惠甄曲家封芮羿储靳汲邴糜松井卞樊赖湛汪][\u4e00-\u9fa5]{1,2})'
            matches = re.findall(pattern, content)
            
            for name in matches[:5]:
                if len(name) >= 2 and len(name) <= 3:
                    if name not in characters:
                        characters[name] = {
                            'name': name,
                            'first_appearance': chapter,
                            'appearances': [chapter]
                        }
        
        return characters
    
    def _guess_identity(self, name: str, context: str) -> str:
        """猜测人物身份"""
        identities = []
        
        if any(x in context for x in ['医生', '医院', '治病', '病人']):
            identities.append('医生')
        if any(x in context for x in ['老师', '教授', '学生', '学校']):
            identities.append('教育界')
        if any(x in context for x in ['厅长', '处长', '科长', '公务员', '机关']):
            identities.append('官场')
        if any(x in context for x in ['老板', '经理', '公司', '生意']):
            identities.append('商界')
        
        return ','.join(identities) if identities else '待补充'
    
    def _extract_concepts(self, chunks: List[Dict]) -> Dict[str, Dict]:
        """
        提取概念（修复版）
        使用 TF-IDF 提取关键词
        """
        try:
            import jieba.analyse
        except ImportError:
            return {}
        
        concepts = {}
        
        for chunk in chunks:
            content = chunk['content']
            chapter = chunk['chapter']
            
            # 使用 TF-IDF 提取关键词
            keywords = jieba.analyse.extract_tags(
                content,
                topK=30,
                withWeight=False,
                allowPOS=('n', 'vn', 'v')  # 名词、动名词、动词
            )
            
            for kw in keywords:
                # 过滤
                if len(kw) < 2:
                    continue
                if kw in STOPWORDS:
                    continue
                if any(kw.endswith(s) for s in EXCLUDE_SUFFIXES):
                    continue
                
                if kw not in concepts:
                    concepts[kw] = {
                        'name': kw,
                        'first_appearance': chapter,
                        'chapters': [chapter],
                        'type': self._guess_concept_type(kw, content)
                    }
                else:
                    if chapter not in concepts[kw]['chapters']:
                        concepts[kw]['chapters'].append(chapter)
        
        print(f"    识别概念：{len(concepts)} 个")
        
        return concepts
    
    def _guess_concept_type(self, concept: str, context: str) -> str:
        """猜测概念类型"""
        if any(x in context for x in ['官场', '机关', '单位', '领导']):
            return '官场'
        elif any(x in context for x in ['理想', '现实', '原则', '信念']):
            return '思想'
        elif any(x in context for x in ['爱情', '婚姻', '家庭', '感情']):
            return '情感'
        else:
            return '通用'
    
    def _build_timeline(self, chunks: List[Dict]) -> List[Dict]:
        """构建时间线"""
        timeline = []
        
        time_patterns = [
            r'(\d{4}) 年',
            r'(\d{4}) 年 (\d{1,2}) 月',
            r'(\d{4}) 年 (\d{1,2}) 月 (\d{1,2}) 日',
            r'(80 年代|90 年代|21 世纪)',
            r'(春天|夏天|秋天|冬天|清晨|黄昏|夜晚)'
        ]
        
        for chunk in chunks:
            content = chunk['content']
            chapter = chunk['chapter']
            
            for pattern in time_patterns:
                matches = re.findall(pattern, content)
                if matches:
                    timeline.append({
                        'chapter': chapter,
                        'time_expression': str(matches[0]),
                        'content': content[:100]
                    })
                    break
        
        return timeline
    
    def _extract_locations(self, chunks: List[Dict]) -> Dict[str, Dict]:
        """提取地点"""
        locations = {}
        
        location_keywords = [
            '卫生厅', '办公室', '会议室', '医院', '学校',
            '北京', '上海', '广州', '省城', '县城', '农村'
        ]
        
        for chunk in chunks:
            content = chunk['content']
            chapter = chunk['chapter']
            
            for loc in location_keywords:
                if loc in content:
                    if loc not in locations:
                        locations[loc] = {
                            'name': loc,
                            'type': '地点',
                            'chapters': [chapter],
                            'description': ''
                        }
                    else:
                        if chapter not in locations[loc]['chapters']:
                            locations[loc]['chapters'].append(chapter)
        
        print(f"    识别地点：{len(locations)} 个")
        
        return locations
    
    def _extract_events(self, chunks: List[Dict]) -> Dict[str, Dict]:
        """提取事件"""
        events = {}
        
        event_keywords = [
            '第一次', '开始', '结束', '发现', '死亡',
            '会议', '决定', '行动', '实验', '分配', '毕业'
        ]
        
        for chunk in chunks:
            content = chunk['content']
            chapter = chunk['chapter']
            
            for kw in event_keywords:
                if kw in content[:100]:  # 段首更可能是事件
                    event_key = f"ch{chapter}_{kw}"
                    if event_key not in events:
                        events[event_key] = {
                            'keyword': kw,
                            'chapter': chapter,
                            'content': content[:200]
                        }
        
        return events
    
    def export(self) -> Dict[str, str]:
        """导出为 Markdown 格式"""
        outputs = {}
        outputs['人物志.md'] = self._format_characters()
        outputs['时间线.md'] = self._format_timeline()
        outputs['概念集.md'] = self._format_concepts()
        outputs['地点集.md'] = self._format_locations()
        outputs['事件簿.md'] = self._format_events()
        return outputs
    
    def _format_characters(self) -> str:
        """格式化人物志"""
        md = f"# 人物志\n\n共记录 {len(self.characters)} 个人物\n\n---\n\n"
        
        for name, info in sorted(self.characters.items(), 
                                 key=lambda x: x[1]['first_appearance']):
            md += f"## {name}\n\n"
            md += f"- **首次出场**: 第{info['first_appearance']}章\n"
            md += f"- **出场章节**: {len(info['appearances'])} 章\n"
            md += f"- **身份**: {info.get('identity', '待补充')}\n"
            md += f"- **关系**: {', '.join(info['relations']) if info['relations'] else '待补充'}\n"
            md += "\n---\n\n"
        
        return md
    
    def _format_concepts(self) -> str:
        """格式化概念集"""
        md = f"# 概念集\n\n共记录 {len(self.concepts)} 个概念\n\n---\n\n"
        
        for name, info in sorted(self.concepts.items(), key=lambda x: len(x[1]['chapters']), reverse=True)[:50]:
            md += f"## {name}\n\n"
            md += f"- **类型**: {info.get('type', '通用')}\n"
            md += f"- **出现章节**: {len(info['chapters'])} 章\n"
            md += "\n---\n\n"
        
        return md
    
    def _format_timeline(self) -> str:
        """格式化时间线"""
        md = f"# 时间线\n\n共记录 {len(self.timeline)} 个时间点\n\n---\n\n"
        for event in sorted(self.timeline, key=lambda x: x['chapter'])[:20]:
            md += f"### 第{event['chapter']}章\n\n"
            md += f"**时间**: {event['time_expression']}\n\n"
            md += f"**内容**: {event['content']}...\n\n---\n\n"
        return md
    
    def _format_locations(self) -> str:
        """格式化地点集"""
        md = f"# 地点集\n\n共记录 {len(self.locations)} 个地点\n\n---\n\n"
        for name, info in sorted(self.locations.items()):
            md += f"## {name}\n\n"
            md += f"- **出现章节**: {len(info['chapters'])} 章\n"
            md += "\n---\n\n"
        return md
    
    def _format_events(self) -> str:
        """格式化事件簿"""
        md = f"# 事件簿\n\n共记录 {len(self.events)} 个事件\n\n---\n\n"
        for key, info in sorted(self.events.items())[:30]:
            md += f"## 第{info['chapter']}章：{info['keyword']}\n\n"
            md += f"{info['content']}...\n\n---\n\n"
        return md
    
    def save(self, output_dir: str):
        """保存知识库"""
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        outputs = self.export()
        
        for filename, content in outputs.items():
            filepath = output_dir / filename
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"  💾 已保存：{filepath}")


def main():
    """测试"""
    chunks_path = Path('data/chunks/chunks.json')
    with open(chunks_path, 'r', encoding='utf-8') as f:
        chunks = json.load(f)
    
    builder = KnowledgeBaseBuilder()
    builder.build_from_chunks(chunks)
    builder.save('data/knowledge_base')


if __name__ == "__main__":
    main()
