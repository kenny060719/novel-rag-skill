#!/bin/bash
# 一键安装依赖脚本

echo "============================================================"
echo "📦 智能小说复述 Skill - 依赖安装"
echo "============================================================"
echo ""

# 选择安装方案
echo "请选择安装方案:"
echo "  1. 核心依赖 (5-10 分钟) - 满足基本需求"
echo "  2. 完整依赖 (10-15 分钟) - 推荐"
echo "  3. 优化依赖 (15-20 分钟) - 最佳效果"
echo "  4. 仅检查状态"
echo ""
read -p "请输入选项 (1-4): " choice

case $choice in
    1)
        echo ""
        echo "📦 安装核心依赖..."
        pip3 install faiss-cpu sentence-transformers jieba -q
        ;;
    2)
        echo ""
        echo "📦 安装完整依赖..."
        pip3 install faiss-cpu sentence-transformers jieba chromadb -q
        ;;
    3)
        echo ""
        echo "📦 安装优化依赖..."
        pip3 install faiss-cpu sentence-transformers jieba chromadb m3e-base spacy -q
        echo "📦 下载中文 NER 模型..."
        python3 -m spacy download zh_core_web_sm -q
        ;;
    4)
        echo ""
        echo "🔍 检查依赖状态..."
        ;;
    *)
        echo "❌ 无效选项"
        exit 1
        ;;
esac

echo ""
echo "============================================================"
echo "🔍 检查安装结果"
echo "============================================================"
echo ""

python3 -c "
import sys

modules = {
    'faiss': 'faiss-cpu',
    'sentence_transformers': 'sentence-transformers',
    'jieba': 'jieba',
    'chromadb': 'chromadb',
    'm3e': 'm3e-base',
    'spacy': 'spacy'
}

installed = 0
missing = 0

for module, name in modules.items():
    try:
        __import__(module)
        print(f'  ✅ {name}')
        installed += 1
    except ImportError:
        print(f'  ❌ {name}')
        missing += 1

print(f'\n总计：{installed} 个已安装，{missing} 个未安装')

if missing == 0:
    print('\n✅ 所有依赖安装完成！')
    print('\n下一步:')
    print('  1. 运行测试：bash test_full.sh')
    print('  2. 或运行：python3 src/main.py build <书籍文件>')
else:
    print('\n⚠️  部分依赖未安装，但不影响基本功能')
"

echo ""
echo "============================================================"
