# 📚 智能小说复述 Skill - 用户使用指南

**版本**: v3.0（全自动）  
**更新日期**: 2026-03-29

---

## 🎯 一句话完成全流程

**用户只需说**：
```
请帮我复述《沧浪之水》这本书
```

**系统自动完成**：
```
✅ 创建 subspawn 子代理
✅ 格式转换（WPS/EPUB/PDF → TXT）
✅ 章节切分 + 向量索引
✅ 知识库构建（人物/概念/地点）
✅ 风格分析
✅ 逐章创作（用自己的话）
✅ 严格质检（抄袭检测 + 完整性）
✅ 输出复述稿
```

**耗时**: 约 10-15 分钟（60 万字书籍）

---

## 📋 完整流程

### 用户输入
```
请帮我复述《沧浪之水》这本书
```

### 系统自动执行

#### 阶段 1：自动创建 subspawn（1 分钟）
```python
# 主代理自动创建 4 个子代理
subagents = {
    'preprocessor': spawn(
        agentId='kyle',
        task='格式转换 + 章节切分',
        mode='run',
        runtime='subagent'
    ),
    'indexer': spawn(
        agentId='kyle',
        task='向量索引构建',
        mode='run',
        runtime='subagent'
    ),
    'kb_builder': spawn(
        agentId='kyle',
        task='知识库构建',
        mode='run',
        runtime='subagent'
    ),
    'style_analyzer': spawn(
        agentId='kyle',
        task='风格分析',
        mode='run',
        runtime='subagent'
    )
}
```

#### 阶段 2：并行处理（5 分钟）
- 子代理 1：格式转换 + 章节切分
- 子代理 2：向量化 + 建索引
- 子代理 3：抽取人物/概念/地点
- 子代理 4：分析原著风格

#### 阶段 3：批量创作（10 分钟）
```python
# 每 5 章一批，并行创作
for batch in range(0, total_chapters, 5):
    batch_sessions = []
    
    for ch in range(batch, min(batch + 5, total_chapters)):
        session = spawn(
            agentId='kyle',
            task=f'创作第{ch}章（用自己的话，严格质检）',
            mode='run',
            runtime='subagent'
        )
        batch_sessions.append(session)
    
    # 等待这批完成
```

#### 阶段 4：输出结果（1 分钟）
```
novel-rag-沧浪之水-output/
└── final/
    ├── chapter_001.md (带质检报告)
    ├── chapter_002.md
    └── ...
```

---

## 🚀 使用方式

### 方式 1：飞书消息（推荐）

**用户发送**：
```
请帮我复述《沧浪之水》这本书
```

**系统回复**：
```
📚 已启动《沧浪之水》复述任务

✅ 子代理已创建：
- 预处理：agent:kyle:subagent:xxx
- 索引构建：agent:kyle:subagent:yyy
- 知识库：agent:kyle:subagent:zzz
- 风格分析：agent:kyle:subagent:aaa

⏳ 预计耗时：15 分钟
📁 输出位置：novel-rag-沧浪之水-output/

完成后将自动通知您！
```

---

### 方式 2：命令行

```bash
# 一句话完成全流程
python3 src/main.py auto "请帮我复述《沧浪之水》"

# 或者指定书籍文件
python3 src/main.py auto ~/Desktop/沧浪之水.wps
```

---

### 方式 3：API 调用

```python
from novel_rag_skill import AutoReproducer

# 创建自动复述器
reproducer = AutoReproducer()

# 一句话完成全流程
result = reproducer.reproduce("请帮我复述《沧浪之水》")

# 获取结果
print(f"复述完成：{result.output_dir}")
print(f"质量评分：{result.avg_score}/100")
```

---

## 📊 自动化细节

### 自动检测书籍位置
```python
# 自动搜索常见位置
search_paths = [
    '~/Desktop/',
    '~/Documents/',
    '~/Downloads/',
    './workspace/'
]

# 自动匹配书名
book_path = auto_find_book("沧浪之水")
```

### 自动创建 subspawn
```python
def auto_create_subagents(task_type: str):
    """自动创建子代理"""
    
    if task_type == 'index':
        # 索引构建任务
        return {
            'splitter': spawn(task='文档切分', ...),
            'indexer': spawn(task='向量索引', ...),
            'kb': spawn(task='知识库', ...),
            'style': spawn(task='风格分析', ...)
        }
    
    elif task_type == 'create':
        # 创作任务
        sessions = []
        for ch in range(1, total_chapters + 1):
            sessions.append(
                spawn(task=f'创作第{ch}章', ...)
            )
        return sessions
    
    elif task_type == 'qa':
        # 质检任务
        return spawn(task='严格质检', ...)
```

### 自动质检
```python
def auto_quality_check(paraphrase: str, source: str) -> Dict:
    """自动质检"""
    
    # 1. 抄袭检测
    plagiarism = check_plagiarism(paraphrase, source)
    
    # 2. 完整性检查
    completeness = check_completeness(paraphrase, source)
    
    # 3. 原创性评分
    originality = check_originality(paraphrase)
    
    # 4. 字数检查
    word_count = check_word_count(paraphrase)
    
    # 5. 自动判定
    total_score = (
        plagiarism['score'] * 0.4 +
        completeness['score'] * 0.3 +
        originality['score'] * 0.2 +
        word_count['score'] * 0.1
    )
    
    return {
        'total_score': total_score,
        'passed': total_score >= 80,
        'errors': collect_errors(...)
    }
```

### 自动输出
```python
def auto_save_result(chapter_num: int, content: str, qa_report: Dict):
    """自动保存结果"""
    
    output_dir = Path(f'novel-rag-{book_title}-output/final')
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 保存复述稿（带质检报告）
    with open(output_dir / f'chapter_{chapter_num:03d}.md', 'w') as f:
        f.write(f"""---
chapter: {chapter_num}
book: {book_title}
generated_at: {datetime.now().isoformat()}
quality_score: {qa_report['total_score']}
quality_level: {get_level(qa_report['total_score'])}
status: {"passed" if qa_report['passed'] else "needs_review"}
---

{content}

---

## 质检报告

{qa_report['report']}
""")
```

---

## 📁 输出说明

### 输出目录结构
```
novel-rag-书名-output/
├── final/                    # 最终版复述稿
│   ├── chapter_001.md
│   ├── chapter_002.md
│   └── ...
├── drafts/                   # 草稿版本
│   ├── draft_v1/
│   └── draft_v2/
├── reports/                  # 质量报告
│   ├── quality_report.md
│   └── global_quality_report.md
└── full_book.md              # 全书合并稿
```

### 复述稿格式
```markdown
---
chapter: 1
book: 沧浪之水
generated_at: 2026-03-29T22:00:00
quality_score: 92
quality_level: A
status: passed
---

# 第 1 章：研究生毕业

[开篇概述]
1985 年，池大为从研究生毕业，被分配到省卫生厅工作...

[情节发展]
在办公室，池大为与丁小槐共事。丁小槐精于人情世故...

[高潮部分]
一次全省中药市场整顿的调查中，池大为发现了马塘铺市场假药泛滥...

[结局概述]
这次事件让池大为第一次深刻体会到官场的复杂...

【情节来源】
- 主要情节来自原著第 1 章

---

## 质检报告

### 抄袭检测
- 结果：✅ 通过
- 说明：无连续 10 字相同

### 完整性
- 结果：✅ 通过
- 覆盖：95% 情节点

### 原创性
- 结果：✅ 通过
- 说明：用自己的话表达

### 字数
- 结果：✅ 通过
- 字数：943 字

### 总分
- 分数：92/100
- 等级：A
- 状态：通过
```

---

## 🔧 配置说明

### 自动配置（默认）
```yaml
# 用户无需配置，系统自动处理

auto:
  # 自动搜索书籍位置
  search_paths: ['~/Desktop/', '~/Documents/']
  
  # 自动创建 subspawn
  parallel_batches: 5  # 每批 5 章
  
  # 自动质检标准
  quality_threshold: 80  # 80 分通过
  
  # 自动输出位置
  output_format: 'novel-rag-{书名}-output'
```

### 自定义配置（可选）
```yaml
# 高级用户可自定义
custom:
  # 指定书籍路径
  book_path: '/path/to/book.wps'
  
  # 指定输出目录
  output_dir: '/path/to/output'
  
  # 指定风格
  style: '简洁现代'  # 忠实原著/简洁现代/学术风格/通俗口语
  
  # 指定章节范围
  chapters: [1, 10]  # 只复述第 1-10 章
```

---

## 💡 常见问题

### Q1: 如何知道 subspawn 执行情况？
**A**: 系统会自动回复子代理信息：
```
✅ 子代理已创建：
- 预处理：agent:kyle:subagent:xxx
- 索引构建：agent:kyle:subagent:yyy
...
```

### Q2: 如何查看进度？
**A**: 发送"查看进度"，系统自动回复：
```
📊 进度：35/50 章 (70%)
✅ 已通过：33 章
⏳ 创作中：2 章
⏸️ 待开始：15 章
```

### Q3: 质量不合格怎么办？
**A**: 系统自动修订：
```
⚠️  第 5 章质检未通过（75 分）
🔄 自动修订中...
✅ 修订完成（88 分，通过）
```

### Q4: 可以中途停止吗？
**A**: 可以，发送"暂停"或"停止"：
```
⏸️ 已暂停创作
✅ 已完成：20 章
💾 已保存进度
发送"继续"恢复创作
```

---

## 🎯 完整示例

### 用户输入
```
请帮我复述《沧浪之水》这本书
```

### 系统自动执行

**1. 自动搜索书籍**
```
🔍 正在搜索《沧浪之水》...
✅ 找到：~/Desktop/《沧浪之水》阎真.wps
```

**2. 自动创建 subspawn**
```
🚀 创建子代理...
✅ 预处理：agent:kyle:subagent:0273195c
✅ 索引构建：agent:kyle:subagent:35df4fa3
✅ 知识库：agent:kyle:subagent:8690626b
✅ 风格分析：agent:kyle:subagent:ae895f52
```

**3. 自动并行处理**
```
⏳ 处理中...
✅ 格式转换完成
✅ 章节切分完成（50 章）
✅ 向量索引完成（1500 个片段）
✅ 知识库完成（14 个人物，1153 个概念）
✅ 风格分析完成
```

**4. 自动批量创作**
```
✍️  开始创作...
📊 第 1 批（1-5 章）：完成，平均 92 分
📊 第 2 批（6-10 章）：完成，平均 89 分
📊 第 3 批（11-15 章）：完成，平均 91 分
...
```

**5. 自动输出结果**
```
✅ 创作完成！

📁 输出位置：
/home/admin/openclaw/workspace/agents/Kyle/workspace/novel-rag-沧浪之水-output/final/

📊 质量统计：
- 总章节：50 章
- 平均评分：90/100
- 通过率：100%
- 总字数：45,000 字

📄 查看复述稿：
cat novel-rag-沧浪之水-output/final/chapter_001.md
```

---

## 📝 技术实现

### 主入口（自动模式）
```python
# src/main.py

def main():
    if sys.argv[1] == 'auto':
        # 自动模式：一句话完成全流程
        user_input = sys.argv[2] if len(sys.argv) > 2 else ""
        
        # 创建自动复述器
        reproducer = AutoReproducer()
        
        # 执行全流程
        result = reproducer.reproduce(user_input)
        
        # 输出结果
        print(f"✅ 复述完成：{result.output_dir}")

class AutoReproducer:
    """自动复述器"""
    
    def reproduce(self, user_input: str) -> Result:
        """一句话完成全流程"""
        
        # 1. 解析用户输入
        book_title = self._parse_book_title(user_input)
        
        # 2. 搜索书籍
        book_path = self._find_book(book_title)
        
        # 3. 创建 subspawn
        subagents = self._create_subagents(book_path)
        
        # 4. 等待完成
        self._wait_all(subagents)
        
        # 5. 汇总结果
        result = self._collect_results(subagents)
        
        return result
```

---

## 🎉 总结

**用户只需一句话**：
```
请帮我复述《沧浪之水》这本书
```

**系统自动完成**：
- ✅ 自动搜索书籍
- ✅ 自动创建 subspawn
- ✅ 自动并行处理
- ✅ 自动批量创作
- ✅ 自动严格质检
- ✅ 自动输出结果

**全程无需用户干预**！📊
